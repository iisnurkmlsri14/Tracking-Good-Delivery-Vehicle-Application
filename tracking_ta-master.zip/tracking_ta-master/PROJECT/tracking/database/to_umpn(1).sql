-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Nov 2019 pada 03.38
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `to_umpn`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `no_kwitansi` varchar(100) NOT NULL,
  `name_peserta` varchar(100) NOT NULL,
  `asal_sekolah` varchar(255) NOT NULL,
  `no_wa` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status_pembayaran` varchar(10) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `jenis_pembayaran` varchar(10) NOT NULL,
  `status_sertifikat` varchar(10) NOT NULL,
  `tgl_pendaftaran` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `pic` varchar(100) NOT NULL,
  `wilayah` varchar(100) NOT NULL,
  `aktif` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `register`
--

INSERT INTO `register` (`id`, `no_kwitansi`, `name_peserta`, `asal_sekolah`, `no_wa`, `email`, `status_pembayaran`, `image`, `jenis_pembayaran`, `status_sertifikat`, `tgl_pendaftaran`, `created_at`, `pic`, `wilayah`, `aktif`) VALUES
(22, 'S0001', 'MUHAMAT ZAENAL MAHMUT', 'SMK NEGERI 1 CERME', '082338875902', 'muhamatzaenalmahmut@gmail.com', '1', NULL, '0', '0', '18-11-2019', '2019-11-17 23:39:40', 'Muhamat Zaenal Mahmut', 'Surabaya', 1),
(23, 'S0002', 'MUHAMAT ZAENAL MAHMUT', 'SMK NEGERI 1 CERME', '082338875902', 'muhamatzaenalmahmut@gmail.com', '1', NULL, '0', '0', '18-11-2019', '2019-11-17 23:42:18', 'Muhamat Zaenal Mahmut', 'Surabaya', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nrp` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `devices` varchar(255) NOT NULL,
  `aktif` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `role_id`, `nama`, `email`, `nrp`, `password`, `devices`, `aktif`) VALUES
(1, 1, 'Muhamat Zaenal Mahmut', 'muhamatzaenalmahmut@gmail.com', 2103161040, '$2y$10$BeOoZIdgl.n9MJ5DIm244.bpawor4ytRxwG6jdafZDeIaQqmYAQHS', 'A203', 0),
(6, 1, 'zencode', 'zencode@gmail.com', 2103161050, '$2y$10$D.jPAL85bCD5/DgFNeeF6.HVjeN.0epO9RfQ7DSioBxPxbLm7NQvO', '', 0),
(8, 2, 'Zaky', 'ddfdfdsf', 2049044, '$2y$10$GanC55LaeXWFSCaI86XpfOoUJb1Ptd/TiCd2wLMD594ooWbRQV8ee', '-', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `wilayah`
--

CREATE TABLE `wilayah` (
  `id` int(11) NOT NULL,
  `wilayah` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `wilayah`
--

INSERT INTO `wilayah` (`id`, `wilayah`) VALUES
(1, 'Surabaya'),
(2, 'Tuban'),
(3, 'Kediri'),
(5, 'Lamongan');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indeks untuk tabel `wilayah`
--
ALTER TABLE `wilayah`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `wilayah`
--
ALTER TABLE `wilayah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
