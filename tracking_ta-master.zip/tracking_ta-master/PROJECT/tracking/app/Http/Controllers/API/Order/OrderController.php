<?php

namespace App\Http\Controllers\API\Order;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Order\Order;
use App\Models\DetailOrder\DetailOrder;
use App\Models\Truck\Truck;

class OrderController extends Controller
{ 
    public function getData(){
        $truck = Truck::count();
        $orderON = DetailOrder::where(['status' => 1])->count();
        $orderOFF = DetailOrder::where(['status' => 0])->count();
        $params = [
            'truck' => $truck,
            'orderON' => $orderON,
            'orderOFF' => $orderOFF
        ];
        return response()->json($params);
    }

    public function getAllOrder(){
        $data = Order::where(['status' => 1])->get();
        $params = [
            'code' => 200,
            'status' => 'success',
            'data' => $data
            ];
        return response()->json($params);
    }

    public function getAllOrderHistory(){
        $data = Order::where(['status' => 0])->get();
        $params = [
            'code' => 200,
            'status' => 'success',
            'data' => $data
        ];
        return response()->json($params);
    }

    public function addOrder(Request $request){
        $apiName = 'ADD_TRUCK';
        $id_truck  = strtoupper($request->id_truck);
        $nama_kurir  = strtoupper($request->nama_kurir);
        
        $sendingParams = [
            'id_truck' => $id_truck,
            'nama_kurir' => $nama_kurir,
        ];

        try{
            $data = new Order();
            $data->id_truck=$id_truck;
            $data->nama_kurir=$nama_kurir;
            $data->save();

            $idHeader = substr($data->id, 0);

            $detail = json_decode($request->detail);
            $currentParams=[];

            foreach($detail as $key => $value){
                $currentParams[] = [
                    'id_order' => $data->id,
                    'id_customers' => $value->id_customers,
                    'nama_barang' => $value->nama_barang,
                    'destinasion' => $value->destinasion,
                    'status' => 1,
                    'note' => null
                ];
            }

            DetailOrder::insert($currentParams);

            $params = [
                'code' => 200,
                'status' => 'success',
                'data' => $data
            ];

            return response()->json($params);

        }catch (Exception $e){
            return $this->messageSystem->returnApiMessage($apiName,404, $e->getMessage(),json_encode($sendingParams));

        }
        return response()->json($params);
    }

    public function deleteOrder(Request $request){
        $apiName='DELETE_ORDER';
        $id=$request->id;
        $sendingParams = [
            'id' => $id,
        ];

        try {
            Order::find($id)->delete();
            $params = [
                'code' => 200,
                'status' => 'success',
            ];
            return response()->json($params);

        } catch (Exception $e){
            return $this->messageSystem->returnApiMessage($apiName,404, $e->getMessage(),json_encode($sendingParams));
        }
    }

    //DETAIL ORDER
    public function getAllDetailOrder(){
        $data = DetailOrder::where(['status' => 1])->get();
        $params = [
            'code' => 200,
            'status' => 'success',
            'data' => $data
        ];
        return response()->json($params);
    }

    public function getAllDetailOrderHistory(){
        $data = DetailOrder::where(['status' => 0])->get();
        $params = [
            'code' => 200,
            'status' => 'success',
            'data' => $data
        ];
        return response()->json($params);
    }

    public function getDetailOrderByID(Request $request){
        $id_order = $request->id_order;
        $data =  DetailOrder::where(['id_order' => $id_order])->get();

        $params = [
            'code' => 200,
            'status' => 'success',
            'data' => $data
        ];
        return response()->json($params);
    }

    public function getDetailOrderByCustomers(Request $request){
        $id_customers = $request->id_customers;
        $type = $request->type;
        $data =  DetailOrder::where(['id_customers' => $id_customers, 'status' => $type])->get();

        $params = [
            'code' => 200,
            'status' => 'success',
            'data' => $data
        ];
        return response()->json($params);
    }

    public function verifikasiOrder(Request $request){
        $id = $request->id;
        $id_order = $request->id_order;
        $note = $request->note;

        $total = DetailOrder::where(['id_order' => $id_order, 'status' => 1])->count();

        DetailOrder::where('id', $id)->update(['status' => 0, 'note' => $note]);

        if($total == 1){
            Order::where('id', $id_order)->update(['status' => 0]);
        }

        $params = [
            'code' => 200,
            'status' => 'success',
        ];
        return response()->json($params);
    }
}
