<?php

namespace App\Http\Controllers\Api\GPS;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Gps\Gps;
use App\Models\Order\Order;

class GPSController extends Controller
{
    public function getGPSOne(Request $request){
        $id_truck = $request->id_truck;
        $id_order = $request->id_order;

        if($id_truck == null){
            $data = Order::where(['id' => $id_order])->latest()->first();
            $id_truck = $data->id_truck;
        }

        $data = Gps::where(['id_truck' => $id_truck])->latest()->first();

        if($data){
            $params = [
                'longitude' => $data->longitude,
                'latitude' => $data->latitude
            ];
        } else {
            $params = [
                'longitude' => 0,
                'latitude' => 0
            ];
        }
        return response()->json($params);
    }
}
