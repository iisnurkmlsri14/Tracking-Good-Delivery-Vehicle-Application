<?php

namespace App\Http\Controllers\Api\Devices;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Devices\Devices;

class DevicesController extends Controller
{
    public function cekDevices(Request $request){
        $idDevices = $request->idDevices;

        $data = Devices::where(['devices' => $idDevices])->first();

        if($data != null){
            if($data->aktif == 1){
                $params = [
                    'code' => 200,
                    'status' => 'success',
                    'data' => $data,
                ];
            } else {
                $params = [
                    'code' => 404,
                    'status' => 'failed',
                    'data' => 'DEVICES TIDAK DITEMUKAN',
    
                ];
            }
            
        } else {
            $params = [
                'code' => 404,
                'status' => 'failed',
                'data' => 'DEVICES TIDAK DITEMUKAN',

            ];
        }
        return response()->json($params);
    }

    public function insertDevices(Request $request){
        $idDevices = $request->idDevices;
        $id = $request->id;

        Devices::where('id', $id)->update(['devices' => $idDevices]);
        Devices::where('id', $id)->update(['aktif' => 1]);

        $params = [
            'code' => 200,
            'status' => 'success',
        ];
        return response()->json($params);
    }

    public function logoutDevices(Request $request){
        $id = $request->id;

        Devices::where('id', $id)->update(['aktif' => 0]);

        $params = [
            'code' => 200,
            'status' => 'success',
        ];
        return response()->json($params);
    }


    public function addOrderPersonal(Request $request)
    {
        $apiName='ORDERPERSONALCONTROLLER';
        $kode_order=$request->kode_order;
        $unit=$request->unit;


        $cekEmployee=User::where('no_badge', $no_badge)->first();

        try {
            $data = new OrderAPD();

            $data->kode_order="RID-".$request->id;
            $data->no_badge=$cekEmployee->no_badge;
            $data->individu="1";
            $data->unit="0";


            $data->save();

            $nilai = substr($data->id, 0);
            // dd($nilai);
            $kode = (int) $nilai;
            // dd($data->id);

            $auto_kode = "RID-" .str_pad($kode, 5, "0",  STR_PAD_LEFT);
            $data->kode_order = $auto_kode;
            $data->save();

            $detail = json_decode($request->detail);
            // dd($detail);
            $currentParams=[];

            foreach($detail as $key => $value){
                $dataMaster = MasterAPD::where('kode', $value->kode_apd)->first();

                $currentParams[] = [
                    'kode_order' => $data->id,
                    'kode_apd' => $value->kode_apd,

                ];
            }

            DetailOrder::insert($currentParams);
            $params = [
                'is_success' => true,
                'status' => 200,
                'message' => 'success',
                'data' => $data
            ];
            return response()->json($params);
        } catch (Exception $e) {

            return $this->messageSystem->returnApiMessage($apiName,404,'Failed to save realisasi!',json_encode($sendingParams));
        }
    }

    
}
