<?php

namespace App\Http\Controllers\API\Truck;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Truck\Truck;

class TruckController extends Controller
{ 
    public function getAllTruck(){
        $data = Truck::all();
        $params = [
            'code' => 200,
            'status' => 'success',
            'data' => $data
            ];
        return response()->json($params);
    }

    public function addTruck(Request $request){
        $apiName = 'ADD_TRUCK';
        $nama_truck  = strtoupper($request->nama_truck);
        $nopol  = strtoupper($request->nama_truck);
        
        $sendingParams = [
            'nama_truck' => $nama_truck,
            'nopol' => $nopol,
        ];

        try{
            $data = new Truck();
            $data->nama_truck=$nama_truck;
            $data->nopol=$nopol;
            $data->save();

            $params = [
                'code' => 200,
                'status' => 'success',
                'data' => $data
            ];

            return response()->json($params);

        }catch (Exception $e){
            return $this->messageSystem->returnApiMessage($apiName,404, $e->getMessage(),json_encode($sendingParams));

        }
        return response()->json($params);
    }

    public function deleteTruck(Request $request){
        $apiName='DELETE_TRUCK';
        $id=$request->id;
        $sendingParams = [
            'id' => $id,
        ];

        try {
            Truck::find($id)->delete();
            $params = [
                'code' => 200,
                'status' => 'success',
            ];
            return response()->json($params);

        } catch (Exception $e){
            return $this->messageSystem->returnApiMessage($apiName,404, $e->getMessage(),json_encode($sendingParams));
        }
    }
}
