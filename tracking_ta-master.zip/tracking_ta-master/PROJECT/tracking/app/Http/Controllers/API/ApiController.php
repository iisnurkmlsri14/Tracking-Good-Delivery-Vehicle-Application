<?php

namespace App\Http\Controllers\API;

use App\Http\Requests\RegisterAuthRequest;
use App\User;
use Illuminate\Http\Request;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\Http\Controllers\Controller;

class ApiController extends Controller
{
    public $loginAfterSignUp = true;

    public function getAllRegister(){
        $data = User::all();
        $params = [
            'code' => 200,
            'status' => 'success',
            'data' => $data
            ];
        return response()->json($params);
    }

    public function login(Request $request)
    {
        $input = $request->only('email', 'password');
        $jwt_token = null;

        if (!$jwt_token = JWTAuth::attempt($input)) {
            return response()->json([
                'code' => 401,
                'status' => 'failed'
            ], 401);
        }

        return response()->json([
            'code' => 200,
            'status' => 'success',
            'token' => $jwt_token,
        ]);
    }

    public function validasi(Request $request)
    {
        $this->validate($request, [
            'token' => 'required'
        ]);

        try {
            $user = JWTAuth::authenticate($request->token);

                $params = [
                    'code' => 200,
                    'status' => 'success',
                    'data' => $user
                ];
            return response()->json($params);

        }catch (Exception $ex){
            return $this->messageSystem->returnApiMessage($apiName,404, $e->getMessage(),json_encode($sendingParams));

        }
        return response()->json($params);
    }

    public function addRegister(Request $request){
        $apiName = 'ADD_REGISTER';
        
        $role_id  = $request->role_id;
        $nama  = $request->nama;
        $email  = $request->email;
        $password  = bcrypt($request->password);
        
        $sendingParams = [
            'role_id' => $role_id,
            'nama' => $nama,
            'email' => $email,
            'password' => $password,
        ];
  
        try{
            $data = new User();
            $data->role_id=$role_id;
            $data->nama=$nama;
            $data->email=$email;
            $data->password=$password;
            $data->save();
  
            $params = [
                'code' => 200,
                'status' => 'success',
                'data' => $data
            ];
  
            return response()->json($params);
  
        }catch (Exception $e){
            return $this->messageSystem->returnApiMessage($apiName,404, $e->getMessage(),json_encode($sendingParams));
  
        }
        return response()->json($params);
    }
    
    public function deleteRegister(Request $request){
        $apiName='DELETE_REGISTER';
        $id=$request->id;
        $sendingParams = [
            'id' => $id,
        ];

        try {
            User::find($id)->delete();
            $params = [
                'code' => 200,
                'status' => 'success',
            ];
            return response()->json($params);

        } catch (Exception $e){
            return $this->messageSystem->returnApiMessage($apiName,404, $e->getMessage(),json_encode($sendingParams));
        }
    }
}
