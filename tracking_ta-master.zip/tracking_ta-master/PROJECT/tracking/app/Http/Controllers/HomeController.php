<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Truck\Truck;
use App\Models\Order\Order;
use App\Models\DetailOrder\DetailOrder;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $totalTruck = Truck::count();
        $order = DetailOrder::all();
        $totalOrder = DetailOrder::count();
        $totalOrderFinish = DetailOrder::where(['status' => 1])->count();
        $totalOrderProgress = DetailOrder::where(['status' => 0])->count();

        $params = [
            'totalTruck'=>$totalTruck,
            'totalOrder'=>$totalOrder,
            'totalOrderFinish'=>$totalOrderFinish,
            'totalOrderProgress'=>$totalOrderProgress,
            'order' =>$order,
        ];

        return view('home', $params);
    }
}
