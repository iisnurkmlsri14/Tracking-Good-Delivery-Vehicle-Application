<?php

namespace App\Http\Controllers\Backend\Order;

use Illuminate\Http\Request;
use App\Models\Order\Order;
use App\Models\DetailOrder\DetailOrder;
use App\Models\Truck\Truck;
use Response;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    public function index()
    {
        $order = Order::all();
        $totalOrder = DetailOrder::count();
        $totalOrderFinish = DetailOrder::where(['status' => 1])->count();
        $totalOrderProgress = DetailOrder::where(['status' => 0])->count();

        $params = [
            'order' =>$order,
            'totalOrder'=>$totalOrder,
            'totalOrderFinish'=>$totalOrderFinish,
            'totalOrderProgress'=>$totalOrderProgress,
        ];
       return view('order.index', $params);
   }


    public function form(Request $request)
    {
        $id = $request->input('id');
        $truck = Truck::all();
        if($id){
            $data = Order::find($id);
        }else{
            $data = new Order();
        }
        $params =[
            'title' =>'Manajemen Order',
            'data' =>$data,
            'truck' =>$truck
        ];
        return view('order/form', $params);
    }

    public function save(Request $request)
    {
        $id = intval($request->input('id',0));
        if($id){
            $data = Order::find($id);
        }else{
            $data = new Order();
        }

        $data->id_truck = $request->id_truck;
        $data->nama_kurir = $request->nama_kurir;
      
        try{
            $data->save();
            return "
            <div class='alert alert-success'>Success</div>
            <script> scrollToTop(); reload(1500); </script>";
        } catch (\Exception $ex){
            dd($ex);
            return "<div class='alert alert-danger'>Failed! Order not saved!</div>";
        }
    }

    public function delete(Request $request){

        $id = intval($request->input('id',0));
        try{
            Order::find($id)->delete();
            return "
            <div class='alert alert-success'>Order Remove Success!</div>
            <script> scrollToTop(); reload(1500); </script>";
        }catch(\Exception $ex){
            return "<div class='alert alert-danger'>Remove Failed! Order not removed!</div>";
        }
    }
}
