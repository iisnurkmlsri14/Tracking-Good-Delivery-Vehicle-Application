<?php

namespace App\Http\Controllers\Backend\Order;

use Illuminate\Http\Request;
use App\Models\DetailOrder\DetailOrder;
use Response;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;

class HistoryController extends Controller
{
    public function index()
    {
       $history = DetailOrder::where(['status' => 1])->get();
      
       $params=[
           'history'=>$history,
       ];
       return view('history.index', $params);
   }

   public function delete(Request $request){

       $id = intval($request->input('id',0));
       try{
        DetailOrder::find($id)->delete();
           return "
           <div class='alert alert-success'>Remove Success!</div>
           <script> scrollToTop(); reload(1500); </script>";
       }catch(\Exception $ex){
           return "<div class='alert alert-danger'>Remove Failed! Wilayah not removed!</div>";
       }

   }
}
