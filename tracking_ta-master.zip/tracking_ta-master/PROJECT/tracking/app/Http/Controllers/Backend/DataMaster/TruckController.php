<?php

namespace App\Http\Controllers\Backend\DataMaster;

use Illuminate\Http\Request;
use App\Models\Truck\Truck;
use Response;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;

class TruckController extends Controller
{
    public function index()
    {
       $truck = Truck::all();

       $params=[
           'truck'=>$truck,
       ];

       return view('dataMaster.truck.index', $params);
   }

   public function form(Request $request)
   {
       $id = $request->input('id');
       if($id){
           $data = Truck::find($id);
       }else{
           $data = new Truck();
       }
       $params =[
           'title' =>'Manajemen Truck',
           'data' =>$data,
       ];
       return view('dataMaster.truck.form', $params);
   }

   public function save(Request $request)
   {
       $id = intval($request->input('id',0));
       if($id){
           $data = Truck::find($id);
       }else{
           $data = new Truck();
       }

       $data->nama_truck = $request->nama_truck;
       $data->nopol = $request->nopol;
       try{
           $data->save();
           return "
           <div class='alert alert-success'>Success</div>
           <script> scrollToTop(); reload(1500); </script>";
       } catch (\Exception $ex){
           return "<div class='alert alert-danger'>Failed! Truck not saved!</div>";
       }
   }

   public function delete(Request $request){

       $id = intval($request->input('id',0));
       try{
        Truck::find($id)->delete();
           return "
           <div class='alert alert-success'>Remove Success!</div>
           <script> scrollToTop(); reload(1500); </script>";
       }catch(\Exception $ex){
           return "<div class='alert alert-danger'>Remove Failed! Truck not removed!</div>";
       }

   }
}
