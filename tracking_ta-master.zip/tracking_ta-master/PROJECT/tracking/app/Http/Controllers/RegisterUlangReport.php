<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Register\Register;
use Maatwebsite\Excel\Concerns\FromCollection;

class RegisterUlangReport implements FromCollection
{
    public function __construct(string $wilayah)
    {
        $this->wilayah = $wilayah;
    }

    public function collection()
    {
        return Register::whereRaw("wilayah like '%".$this->wilayah."%' AND status_register like 1")->get();
    }
}