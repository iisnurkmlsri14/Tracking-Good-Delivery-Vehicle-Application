<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

     public function index()
     {
        $users = User::where(['role_id' => 2])->get();
        // $users = User::all();

        $params=[
            'users'=>$users,
        ];

        return view('user/index', $params);
    }

    public function form(Request $request)
    {
        $id = $request->input('id');
        if($id){
            $data = User::find($id);
        }else{
            $data = new User();
        }
        $params =[
            'title' =>'Manajemen User',
            'data' =>$data,
        ];
        return view('user/form', $params);
    }

    public function save(Request $request)
    {
        $id = intval($request->input('id',0));
        if($id){
            $data = User::find($id);
        }else{
            $data = new User();
            $chekEmail = User::where(['email' => $request->email])->first();
            if($chekEmail){
                return "<div class='alert alert-danger'>Email Sudah terdaftar!</div>";
            }
        }

        $data->role_id = 2;
        $data->nama = $request->nama;
        $data->email = $request->email;
        $data->password = bcrypt($request->password);

        try{
            $data->save();
            return "
            <div class='alert alert-success'>Success</div>
            <script> scrollToTop(); reload(1500); </script>";
        } catch (\Exception $ex){
            dd($ex);
            return "<div class='alert alert-danger'>Failed! Customers not saved!</div>";
        }
    }

    public function delete(Request $request){

        $id = intval($request->input('id',0));
        try{
            User::find($id)->delete();
            return "
            <div class='alert alert-success'>User Remove Success!</div>
            <script> scrollToTop(); reload(1500); </script>";
        }catch(\Exception $ex){
            return "<div class='alert alert-danger'>Remove Failed! User not removed!</div>";
        }
    }
}
