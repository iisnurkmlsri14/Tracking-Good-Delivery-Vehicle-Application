<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Register\Register;
use Maatwebsite\Excel\Concerns\FromCollection;

class RegisterReport implements FromCollection
{
    public function __construct(string $wilayah)
    {
        $this->wilayah = $wilayah;
    }

    public function collection()
    {
        return Register::where(['wilayah' => $this->wilayah])->get();
    }
}