<?php
 
namespace App\Mail;
 
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use PDF;

class SendEmail extends Mailable
{
    use Queueable, SerializesModels;
 
 
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($request, $kodeGenerate)
    {
        $this->request = $request;
        $this->kode = $kodeGenerate;
        
        // $this->path = 'temp/freightbild.pdf';
        // $this->pdf = PDF::loadFile()
        // $this->pdf->setPaper('A4', 'portrait');
        $this->pdf = PDF::loadView('getPDF', ['kode'=>$kodeGenerate, 'nama'=>$request->name_peserta])->setPaper('a4', 'portrait');

        // $pdf = PDF::loadView('getPDF', $request)->save($this->path);
    }
 
    public function build()
    {
       return $this->from('toumpn@informateknologi.com')
                   ->view('sendEmail')
                   ->subject('Registrasi Try Out UMPN PENS 2020')
                   ->with(
                    [
                        'kode' => $this->kode,
                        'nama' => strtoupper($this->request->name_peserta),
                        'asal' => strtoupper($this->request->asal_sekolah),
                        'wilayah' => $this->request->wilayah,
                    ])
                    ->attachData($this->pdf->output(), "IDCard.pdf");
    }
}