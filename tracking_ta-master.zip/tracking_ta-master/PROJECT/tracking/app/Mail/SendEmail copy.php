<?php
 
namespace App\Mail;
 
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
 
class SendEmail extends Mailable
{
    use Queueable, SerializesModels;
 
 
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($request, $kodeGenerate)
    {
        $this->request = $request;
        $this->kode = $kodeGenerate; 
    }
 
    public function build()
    {
       return $this->from('toumpn@informateknologi.com')
                   ->view('sendEmail')
                   ->with(
                    [
                        'kode' => $this->kode,
                        'nama' => strtoupper($this->request->name_peserta),
                        'asal' => strtoupper($this->request->asal_sekolah),
                        'wilayah' => $this->request->wilayah,
                    ]);
    }
}