<?php

namespace App\Models\Gps;


use Illuminate\Database\Eloquent\Model;

class Gps extends Model
{
    protected $table = 'gps';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
