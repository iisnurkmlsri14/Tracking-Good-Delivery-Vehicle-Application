<?php

namespace App\Models\DetailOrder;


use Illuminate\Database\Eloquent\Model;

class DetailOrder extends Model
{
    protected $table = 'detail_order';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
