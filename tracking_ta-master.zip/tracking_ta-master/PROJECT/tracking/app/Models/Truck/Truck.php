<?php

namespace App\Models\Truck;


use Illuminate\Database\Eloquent\Model;

class Truck extends Model
{
    protected $table = 'truck';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
