// console.disableYellowBox = true;
// import React, { Component } from "react";
//
// import { createAppContainer } from 'react-navigation';
// import { createStackNavigator } from 'react-navigation-stack';
//
// import LoggedOut from "./src/pages/LoggedOut";
// import HomePage from "./src/pages/HomePage";
// import ObatPage from "./src/pages/ObatPage";
// import DetailObatPage from "./src/pages/DetailObatPage";
// import DetailObatPageDis from "./src/pages/DetailObatPageDis";
// import LogPage from "./src/pages/LogPage";
// import OfflineNotice from "./src/pages/components/OfflineNotice";
// import ApotekPage from "./src/pages/ApotekPage";
// import MapsPage from "./src/pages/MapsPage";
// import AboutUsPage from "./src/pages/AboutUsPage";
// import DisclaimerPage from "./src/pages/DisclaimerPage";
// import ContactPage from "./src/pages/ContactPage";
// import IndicationPage from "./src/pages/IndicationPage";
// import HistoryPage from "./src/pages/HistoryPage";
// import MedicinePage from "./src/pages/MedicinePage";
// import PharmacyPage from "./src/pages/PharmacyPage";
// import Maps from "./src/pages/Maps";
// import SearchList from "./src/pages/SearchList";
// import SettingLanguage from "./src/pages/SettingLanguage";
// const AppNavigator = createStackNavigator({
//   LoggedOut: {
//     screen: LoggedOut
//   },
//   HomePage: {
//     screen: HomePage
//   },
//   ObatPage: {
//     screen: ObatPage
//   },
//   DetailObatPage: {
//     screen: DetailObatPage
//   },
//   DetailObatPageDis:{
//     screen: DetailObatPageDis
//   },
//   LogPage: {
//     screen: LogPage
//   },
//   OfflineNotice: {
//     screen: OfflineNotice
//   },
//   ApotekPage: {
//     screen: ApotekPage
//   },
//   MapsPage: {
//     screen: MapsPage
//   },
//   AboutUsPage: {
//     screen: AboutUsPage
//   },
//   DisclaimerPage: {
//     screen: DisclaimerPage
//   },
//   ContactPage: {
//     screen: ContactPage
//   },
//   IndicationPage:{
//     screen: IndicationPage
//   },
//   HistoryPage:{
//     screen: HistoryPage
//   },
//   MedicinePage:{
//     screen: MedicinePage
//   },
//   PharmacyPage:{
//     screen: PharmacyPage
//   },
//   Maps:{
//     screen: Maps
//   },
//   SearchList:{
//     screen: SearchList
//   },
//   SettingLanguage:{
//     screen: SettingLanguage
//   }
//
// })
//
// const App = createAppContainer(AppNavigator);
//
// export default App;


import React, { Component } from 'react';
import { Root } from './src/routers/mainRouter';

export default class App extends Component {
  render() {
    return (
        <Root />
    );
  }
}
