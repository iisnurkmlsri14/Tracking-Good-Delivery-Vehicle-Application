import React, { Component } from "react";
import {Platform, Image, AsyncStorage, StyleSheet, Alert} from "react-native";
import { Footer, FooterTab, Text, Button, Icon, View, Badge } from "native-base";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../styles/colors/index";
const icon_home = require("../../assets/icon/icon_home.png");
const icon_home_col = require("../../assets/icon/icon_home_colors.png");
const icon_order = require("../../assets/icon/icon_order.png");
const icon_order_col = require("../../assets/icon/icon_order_colors.png");
const icon_surat = require("../../assets/icon/icon_surat.png");
const icon_surat_col = require("../../assets/icon/icon_surat_colors.png");
const icon_fees = require("../../assets/icon/icon_fees.png");
const icon_fees_col = require("../../assets/icon/icon_fees_colors.png");
const icon_account = require("../../assets/icon/icon_account.png");
const icon_account_col = require("../../assets/icon/icon_account_colors.png");

class CustomFooter extends Component {
  constructor(props) {
    super(props);
    this.state = {

    }
  }

  componentDidMount() {

  }

  render() {
    let tab = this.props.tab
    return (
        <View>
         <Footer style={{height: RFValue(50)}}>
            <FooterTab style={{ backgroundColor: colors.white_1st}}>
              <Button
                  vertical
                  onPress={() => this.props.navigation.navigate("Dashboard")}
              >
                <Image source={tab == "Dashboard" ? icon_home_col : icon_home} style={styles.icon}/>
                <Text style={[styles.titleMenu,{color: tab == "Dashboard" ? colors.green_1st : colors.gray_2st}]}>Beranda</Text>
              </Button>

              <Button
                  vertical
                  onPress={() => this.props.navigation.navigate("MyOrder")}
              >
                <Image source={tab == "MyOrder" ? icon_order_col : icon_order} style={styles.icon}/>
                <Text style={[styles.titleMenu,{color: tab == "MyOrder" ? colors.green_1st : colors.gray_2st}]}>Order</Text>
              </Button>

              <Button
                  vertical
                  onPress={() => this.props.navigation.navigate("DeliveryOrder")}
              >
                <Image source={tab == "DeliveryOrder" ? icon_surat_col : icon_surat} style={styles.icon}/>
                <Text style={[styles.titleMenu,{color: tab == "DeliveryOrder" ? colors.green_1st : colors.gray_2st}]}>Srt Jalan</Text>
              </Button>


              <Button
                  vertical
                  onPress={() => this.props.navigation.navigate("Claim")}
              >
                <Image source={tab == "Claim" ? icon_fees_col : icon_fees} style={styles.icon}/>
                <Text style={[styles.titleMenu,{color: tab == "Claim" ? colors.green_1st : colors.gray_2st}]}>Penagihan</Text>
              </Button>

              <Button
                  vertical
                  onPress={() => this.props.navigation.navigate("Account")}
              >
                <Image source={tab == "Account" ? icon_account_col : icon_account} style={styles.icon}/>
                <Text style={[styles.titleMenu,{color: tab == "Account" ? colors.green_1st : colors.gray_2st}]}>Akun</Text>
              </Button>

            </FooterTab>
          </Footer>
        </View>
    );
  }
}

export default CustomFooter;

const styles = StyleSheet.create({
  icon: {
    width:RFValue(25),
    height:RFValue(25),
  },
  titleMenu: {
    fontSize:RFValue(6),
    textAlign:'center',
    fontFamily:'Roboto-Medium'
  }
})
