import React, { Component } from "react";
import {Platform, Image, AsyncStorage, StyleSheet, Alert, TouchableOpacity} from "react-native";
import { Footer, FooterTab, Text, Button, Icon, View, Badge } from "native-base";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../styles/colors/index";
import MyView from "../view/MyView";
const icon_home = require("../../assets/icon/icon_home.png");
const icon_home_col = require("../../assets/icon/icon_home_colors.png");
const icon_order = require("../../assets/icon/icon_order.png");
const icon_order_col = require("../../assets/icon/icon_order_colors.png");
const icon_surat = require("../../assets/icon/icon_surat.png");
const icon_surat_col = require("../../assets/icon/icon_surat_colors.png");
const icon_account = require("../../assets/icon/icon_account.png");
const icon_account_col = require("../../assets/icon/icon_account_colors.png");

class CustomFooter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataProfile: []
    }
  }

  componentDidMount() {
    AsyncStorage.getItem("dataProfile").then(dataProfile => {
      this.setState({
        dataProfile: JSON.parse(dataProfile),
      })
    });
  }

  render() {
    let tab = this.props.tab
    let role = this.state.dataProfile.role_id
    return (
        <View>
          <MyView hide={role == 2}>
         <Footer style={{height: RFValue(50)}}>
            <FooterTab style={{ backgroundColor: colors.white_1st, flexDirection:'row'}}>
              <TouchableOpacity style={styles.flex}
                  onPress={() => this.props.navigation.navigate("Dashboard")}
              >
                <Image source={tab == "Dashboard" ? icon_home_col : icon_home} style={styles.icon}/>
                <Text style={[styles.titleMenu,{color: tab == "Dashboard" ? colors.green_1st : colors.gray_2st}]}>Beranda</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.flex}
                  vertical
                  onPress={() => this.props.navigation.navigate("ListOrderAll")}
              >
                <Image source={tab == "ListOrderAll" ? icon_order_col : icon_order} style={styles.icon}/>
                <Text style={[styles.titleMenu,{color: tab == "ListOrderAll" ? colors.green_1st : colors.gray_2st}]}>Order</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.flex}
                  vertical
                  onPress={() => this.props.navigation.navigate("ListOrderHistory")}
              >
                <Image source={tab == "ListOrderHistory" ? icon_surat_col : icon_surat} style={styles.icon}/>
                <Text style={[styles.titleMenu,{color: tab == "ListOrderHistory" ? colors.green_1st : colors.gray_2st}]}>Histori</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.flex}
                  vertical
                  onPress={() => this.props.navigation.navigate("Account")}
              >
                <Image source={tab == "Account" ? icon_account_col : icon_account} style={styles.icon}/>
                <Text style={[styles.titleMenu,{color: tab == "Account" ? colors.green_1st : colors.gray_2st}]}>Akun</Text>
              </TouchableOpacity>
            </FooterTab>
          </Footer>
          </MyView>
          <MyView hide={role == 1}>
            <Footer style={{height: RFValue(50)}}>
              <FooterTab style={{ backgroundColor: colors.white_1st, flexDirection:'row'}}>
                <TouchableOpacity style={styles.flex2}
                                  vertical
                                  onPress={() => this.props.navigation.navigate("OrderCS")}
                >
                  <Image source={tab == "OrderCS" ? icon_order_col : icon_order} style={styles.icon}/>
                  <Text style={[styles.titleMenu,{color: tab == "OrderCS" ? colors.green_1st : colors.gray_2st}]}>Order</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.flex2}
                                  vertical
                                  onPress={() => this.props.navigation.navigate("OrderHistoryCS")}
                >
                  <Image source={tab == "OrderHistoryCS" ? icon_surat_col : icon_surat} style={styles.icon}/>
                  <Text style={[styles.titleMenu,{color: tab == "OrderHistoryCS" ? colors.green_1st : colors.gray_2st}]}>Histori</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.flex2}
                                  vertical
                                  onPress={() => this.props.navigation.navigate("Account")}
                >
                  <Image source={tab == "Account" ? icon_account_col : icon_account} style={styles.icon}/>
                  <Text style={[styles.titleMenu,{color: tab == "Account" ? colors.green_1st : colors.gray_2st}]}>Akun</Text>
                </TouchableOpacity>
              </FooterTab>
            </Footer>
          </MyView>
        </View>
    );
  }
}

export default CustomFooter;

const styles = StyleSheet.create({
  icon: {
    width:RFValue(25),
    height:RFValue(25),
  },
  titleMenu: {
    fontSize:RFValue(10),
    textAlign:'center',
    fontFamily:'Roboto-Medium'
  },
  flex:{
    width:'25%',
    justifyContent:'center',
    alignItems:'center',
  },
  flex2:{
    width:'33%',
    justifyContent:'center',
    alignItems:'center',
  },
})
