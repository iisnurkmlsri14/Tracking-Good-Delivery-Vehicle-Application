export default {
    URL_SERVER: "http://trackingsistem.kadosurabaya.com/api/",
    // URL_SERVER: "http://192.168.43.63/tracking_ta-master/api/",
};
