import React, { Component } from "react";
import {
  Platform,
  Image,
  AsyncStorage,
  TextInput,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import {
  Footer,
  FooterTab,
  Text,
  Button,
  Icon,
  View,
  Left,
  Body,
  Title,
  Right,
  Header} from "native-base";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../styles/colors/index";
import MyView from "../view/MyView";
const back = require("../../assets/icon/icon_back.png");
const history = require("../../assets/icon/icon_history.png");

class CustomHeader extends Component {
  constructor(props) {
    super(props);
    this.state={

    }
  }

  componentDidMount() {

  }

  render() {
    return (
        <View style={{height:60}}>
          <View style={styles.header}>
            <Left style={{ flex: 1}}>
              <MyView hide={!this.props.left}>
                <TouchableOpacity
                    transparent
                    onPress={()=>this.props.navigation.goBack()}
                    style={styles.btnBack}
                >
                  <Image source={back} style={styles.iconMenu}/>
                </TouchableOpacity>
              </MyView>
            </Left>
            <Body style={{ flex:3, alignItems:'center'}}>
              <Text style={styles.title}>{this.props.title}</Text>
            </Body>

            <Right style={{ flex: 1}}>
              <MyView hide={!this.props.right}>
                <TouchableOpacity
                    transparent
                    onPress={()=>this.props.navigation.navigate(this.props.nav)}
                >
                  <Image source={history} style={styles.iconMenu}/>
                </TouchableOpacity>
              </MyView>
            </Right>
          </View>
        </View>
    );
  }
}

export default CustomHeader;

const styles = StyleSheet.create({
  header: {
    backgroundColor: colors.green_1st,
    height:60,
    flex:1,
    flexDirection:'row'
  },
  icon: {
    color:colors.gray_1st,
    fontSize:RFValue(17),
  },
  title: {
    fontSize:RFValue(17),
    color:colors.gray_1st,
    fontFamily: 'Roboto-Medium',
  },
  btnBack: {
    width:RFValue(30),
    height:RFValue(30),
    justifyContent:'center',
    alignItems:'center'
  },
  iconMenu:{
    width:RFValue(20),
    height: RFValue(20)
  }
});

