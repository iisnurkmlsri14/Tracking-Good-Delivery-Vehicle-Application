import React, { Component, Fragment } from 'react';
import { View, StyleSheet, Dimensions, TextInput, Text, Alert, Image, TouchableOpacity, DatePickerAndroid, Platform, DatePickerIOS } from 'react-native';
import { Input, Button, Header, Badge } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
// import Logo from '../assets/img/logo-phccare.png';

const UkuranBaku = Dimensions.get('window').width;

export default class SearchHeader extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: props.value?props.value: 0,            
        };

    }

    render() {
        return (
            <View style={{
                flexDirection: 'row', 
                justifyContent: 'center',
            }}>
                <Input
                    placeholder={this.props.placeholder?this.props.placeholder:'Cari Dokter'}
                    //editable={false}
                    leftIcon={
                        <TouchableOpacity onPress={this.props.onBack}>
                            <Icon
                                name='angle-left'
                                size={(0.06 * UkuranBaku)}
                                color='#525F7F'
                                style={{
                                    paddingRight: (0.05 * UkuranBaku), 
                                    paddingLeft: (0.012 * UkuranBaku), 
                                    paddingTop: (0.025 * UkuranBaku), 
                                    paddingBottom: (0.025 * UkuranBaku), 
                                    marginTop: -(0.006 * UkuranBaku)
                                }}
                            />
                        </TouchableOpacity>
                    }
                    leftIconContainerStyle={{
                        marginLeft: -5,
                        // height: (0.08 * UkuranBaku),
                    }}
                    rightIcon={
                        <Icon
                        name='search'
                        size={(0.06 * UkuranBaku)}
                        // size={24}
                        color='#c6ced0'
                        style={{marginTop: 0}}
                        />
                    }
                    onChangeText={this.props.text}
                    onChange={this.props.search}
                    returnKeyType={'search'}
                    autoFocus={true}
                    containerStyle={styles.search}
                    inputContainerStyle={{
                        borderBottomWidth: 0,
                        // backgroundColor: 'blue',
                        height: (0.10 * UkuranBaku),
                    }}
                />
            </View>
        );
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        //justifyContent: 'space-between',
        backgroundColor: '#fff',
        alignItems: 'center',
        width: '100%',
    },
    h0: {
        color: '#0f0f51',
        fontSize: 24,
        alignSelf: 'center',
    },
    h1: {
        color: '#008F68',
        fontSize: 40,
    },
    h2: {
        color: '#FAE042',
        fontSize: 18,
        marginTop: 8,
    },
    image: {
        width: 300,
        height: 260,
        justifyContent: 'center',
    },
    search: {
        borderWidth: 1, 
        borderColor: '#c6ced0', 
        borderRadius: 5, 
        //marginLeft: 10, 
        //marginRight: 10,
        marginBottom: 0,
        // flex: 1,
        width: '100%',
        alignSelf: 'center',
        // backgroundColor: 'blue',
        // height: (0.08 * UkuranBaku),
    },
    logo: {
        flex: 1, 
        height: 35, 
        //maxWidth: 40, 
        alignSelf: 'center', 
        //marginLeft: 20, 
        //marginRight: 10
    },
    header: {
        maxHeight: 60, 
        backgroundColor: '#fff', 
        //flex: 1, 
        width: '100%', 
        margin: 0,
        flexDirection: 'row'
    },
    button : {
        flex : 1,
        width : 800,
        backgroundColor: '#008F68',
        color: '#008F68'
    },
    button2 : {
        margin: 2, 
        height: 100, 
        width: 100, 
        backgroundColor: '#000', 
        borderRadius: 5
    },
    topContainer: {
        flex: 2,
        //margin: 0
        //justifyContent: 'center',
        //alignItems: 'center',
    },
    middleContainer: {
        //flex: 2,
        justifyContent: 'flex-start',
        //alignItems: 'center',
        //marginTop: 5,
        marginTop: 1,
        height: 240
    },
    bottomContainer: {
        justifyContent: 'flex-end',
        width: '100%',
        marginTop: 50,
        //padding: 10,
    },
    buttonContainer: {
        backgroundColor: '#008F68',
        borderRadius: 5,
        padding: 8,
        margin: 8,
    },
});
