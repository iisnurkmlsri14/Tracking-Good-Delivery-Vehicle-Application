export default {
  white_1st : '#FFFFFF',
  white_2st : '#F7F7F7',

  green_1st : '#47C363',
  green_2st : '#AAFC9A',
  gray_1st : '#E8E8E8',
  gray_2st : '#CCCCCC',
  gray_3st : '#A7A7A7',


  // white_2st : '#F7F9FB',
  // white_3st : '#F2F2F2',
  // white_4st : '#efefef',
  // gray_1st : '#A8A8A8',
  // gray_2st : '#808080',
  blue_1st : "#118EEA",
  // blue_2st : "#3DA1D5",
  // blue_3st : "#00A7DE",
  // blue_4st : "#428DFF",
  red_1st : '#F86164',
  black_1st : '#000000',
  // orange_1st : '#FF8C00',
};
