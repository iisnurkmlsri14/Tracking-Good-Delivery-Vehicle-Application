import { StyleSheet } from "react-native";
import colors from "../colors/index"
import {RFValue} from "react-native-responsive-fontsize";

const stylesContent = StyleSheet.create({
    container:{
        flex:1
    },
    content:{
        paddingHorizontal:RFValue(15),
        // justifyContent: 'center',
        alignItems:'center'
    },

    btnPrimary:{
        width: '100%',
        height: RFValue(40),
        backgroundColor: colors.green_1st,
        justifyContent:'center',
        alignItems: 'center',
        borderRadius:RFValue(5),
        marginTop: RFValue(50),
        marginBottom:RFValue(10)
    },

    btnPrimaryModal:{
        width: '100%',
        height: RFValue(40),
        backgroundColor: colors.green_1st,
        justifyContent:'center',
        alignItems: 'center',
        borderRadius:RFValue(5),
        marginTop: RFValue(15),
    },

    cardOrder:{
        paddingVertical: RFValue(20),
        paddingHorizontal:RFValue(15),
        flex:1,
        flexDirection:'row'
    },

    // contentPadding:{
    //     paddingHorizontal:RFValue(15),
    //     paddingVertical:RFValue(15)
    // },
    // flexRow:{
    //     flexDirection:'row'
    // },
    //
    // image:{
    //     width: '100%',
    //     height: '100%',
    //     resizeMode:'contain'
    // },
    //
    cardBottomWidth:{
        paddingVertical: RFValue(15),
        paddingHorizontal:RFValue(15),
        flex:1,
        flexDirection:'row',
        borderBottomWidth: 1,
        borderColor: colors.gray_1st
    },
    marker:{
        height: RFValue(50),
        width:RFValue(50)
    },
    //
    // cardBottom:{
    //     paddingVertical: RFValue(10),
    //     flex:1,
    //     flexDirection:'column',
    // },
    //
    // btnSmall: {
    //     backgroundColor:colors.green_1st,
    //     justifyContent:'center',
    //     alignItems:'center',
    //     borderRadius:RFValue(5),
    //     paddingVertical: RFValue(5)
    // },
    //
    // btnFull:{
    //     width: '100%',
    //     height: RFValue(40),
    //     backgroundColor: colors.green_1st,
    //     justifyContent:'center',
    //     alignItems: 'center',
    //     borderRadius:RFValue(5),
    //     marginTop: RFValue(20),
    //     marginBottom:RFValue(10),
    // },
    //
    // cardValue:{
    //     backgroundColor:colors.gray_1st,
    //     justifyContent:'center',
    //     alignItems:'center',
    //     borderRadius:RFValue(5),
    //     paddingVertical: RFValue(2),
    //     paddingHorizontal: RFValue(5)
    // },
    //
    // iconChange:{
    //     fontSize:RFValue(20),
    //     color:colors.green_1st
    // },
    // footerPay:{
    //     height: RFValue(30),
    //     backgroundColor:colors.white_2st,
    //     borderTopWidth:1,
    //     borderTopColor:colors.white_2st,
    //     paddingHorizontal: RFValue(15),
    //     paddingVertical:RFValue(10)
    // },
    border:{
        borderBottomWidth:1,
        borderColor: colors.gray_1st,
        marginHorizontal:RFValue(-15),
        marginVertical:RFValue(10)
    },
})

export default stylesContent;
