import { StyleSheet } from "react-native";
import colors from "../colors/index"
import {RFValue} from "react-native-responsive-fontsize";

const stylesText = StyleSheet.create({
    btnTextPrimary:{
        fontSize:RFValue(14),
        color:colors.white_1st,
        fontWeight:'bold'
    },
    title:{
        color:colors.black_1st,
        textAlign:'left',
        fontSize:RFValue(18),
        fontFamily:'Roboto-Medium'
    },
    textIndex:{
        fontSize:RFValue(13),
        fontFamily:'Roboto-Medium',
    },
    textName:{
        fontSize:RFValue(15),
        fontFamily:'Roboto-Medium',
    },
    textEmail:{
        fontSize:RFValue(13),
        fontFamily:'Roboto-Light',
    },
    titleText:{
        color:colors.black_1st,
        textAlign:'left',
        fontSize:RFValue(12),
        fontFamily:'Roboto-Medium',
    },
    subtitleText:{
        color:colors.black_1st,
        textAlign:'left',
        fontSize:RFValue(12),
        fontFamily:'Roboto-Light'
    },

    // subtitleText:{
    //     color:colors.black_1st,
    //     textAlign:'left',
    //     fontSize:RFValue(12),
    //     fontFamily:'Roboto-Light',
    //     marginBottom:RFValue(5)
    // },
    // small:{
    //     color:colors.black_1st,
    //     textAlign:'left',
    //     fontSize:RFValue(10),
    //     fontFamily:'Roboto-Light'
    // },
    // time:{
    //     color:colors.black_1st,
    //     textAlign:'left',
    //     fontSize:RFValue(11),
    //     fontFamily:'Roboto-Light'
    // },
    // number:{
    //     color:colors.green_1st,
    //     textAlign:'left',
    //     fontSize:RFValue(15),
    //     fontFamily:'Roboto-Medium'
    // },
    // numberSmall:{
    //     color:colors.green_1st,
    //     textAlign:'left',
    //     fontSize:RFValue(12),
    //     fontFamily:'Roboto-Medium'
    // },
    // btnSmall:{
    //     color:colors.white_1st,
    //     textAlign:'left',
    //     fontSize:RFValue(12),
    //     fontFamily:'Roboto-Medium'
    // },
    // textBtnFull:{
    //     fontSize:RFValue(14),
    //     color:colors.white_1st,
    //     fontWeight:'bold',
    //     fontFamily:'Roboto-Medium'
    // },
})

export default stylesText;
