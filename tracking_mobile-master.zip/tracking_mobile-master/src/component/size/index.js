import {
    Dimensions,
} from 'react-native';

const size = Dimensions.get('window').width;

export default {
    small_00 : 0.020 * size,
    small_01 : 0.028 * size,

    small_03 : 0.04 * size,

    large_01 : 0.07 * size,
    large_05 : 0.10 * size,
};
