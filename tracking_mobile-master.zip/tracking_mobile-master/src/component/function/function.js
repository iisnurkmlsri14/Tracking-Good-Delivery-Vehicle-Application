export const cutString = (string) => {
    if(string == undefined) {
        return string;
    } else {
        var str = string;
        let find = str.length;
        for(let i=0; i < str.length; i++){
            if(str[i] == ' '){
                find = i;
                i = str.length
            }
        }
        return str.substring(0,find);
    }
}

export const cutRp = (string) => {
    if(string == undefined) {
        return string;
    } else {
        var str = string;
        var length = str.length;
        var end = length - 3
        return str.substring(0, end);
    }
}

export const getNameDay = (format) => {
    var appDate = format;
    var seperator = "-";

    var dayNameArr = new Array("Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab");
    var dateArr = appDate.split(seperator);
    var month = eval(dateArr[1]);
    var day = eval(dateArr[2]);
    var year = eval(dateArr[0]);

    var totalDays = day + (2 * month) + parseInt(3 * (month + 1) / 5) + year + parseInt(year / 4) - parseInt(year / 100) + parseInt(year / 400) + 2;

    var dayNo = (totalDays % 7);
    if (dayNo == 0) {
        dayNo = 7;
    }
    return dayNameArr[dayNo - 1];
}

export const convertRp = (angka) => {
    var rupiah = '';
    var angkarev = angka.toString().split('').reverse().join('');
    for(var i = 0; i < angkarev.length; i++) if(i%3 == 0) rupiah += angkarev.substr(i,3)+'.';
    return ( 'Rp. '+rupiah.split('',rupiah.length-1).reverse().join(''))
}

export const convertNoRp = (angka) => {
    var rupiah = '';
    var angkarev = angka.toString().split('').reverse().join('');
    for(var i = 0; i < angkarev.length; i++) if(i%3 == 0) rupiah += angkarev.substr(i,3)+'.';
    return ( rupiah.split('',rupiah.length-1).reverse().join(''))
}

export const changeRp = (angka) => {
    var number_string   = angka.replace(/[^,\d]/g, '').toString(),
        split           = number_string.split(','),
        sisa            = split[0].length % 3,
        rupiah          = split[0].substr(0, sisa),
        ribuan          = split[0].substr(sisa).match(/\d{3}/gi);

    if(ribuan){
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }
    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return rupiah
}

export const validationInput = (angka) => {
    var val   = angka.replace(/[^,\d]/g, '').toString(),
        number = val
    return number
}

