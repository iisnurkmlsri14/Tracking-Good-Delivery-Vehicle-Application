import React, { Component } from 'react';

import {
    StyleSheet,
    Text,
    View,
    Modal,
    Image,
    TouchableOpacity
} from 'react-native';
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../styles/colors/index";
import MyView from "../view/MyView";

const Empty2 = props => {
    const {
        empty,
        ...attributes
    } = props;

    this.state = {
        isVisible: false
    }

    return (
         <MyView style={styles.modalBackground} visible={empty ? empty : this.state.isVisible}>
             <Image
                 style={{ width: RFValue(60), height: RFValue(60)}}
                 source={require('../../assets/images/empty_data.png')}
             />
             <Text style={styles.noData}>Tidak Ada Data</Text>
         </MyView>
    )
}

const styles = StyleSheet.create({
    modalBackground: {
        flex: 1,
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'center',
        marginTop: RFValue(50)
    },
    activityIndicatorWrapper: {
        backgroundColor: '#FFFFFF',
        height: 100,
        width: 100,
        borderRadius: 10,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-around'
    },
    noData:{
        fontSize:RFValue(12),
        color:colors.gray_3st,
        fontFamily: 'Roboto-Medium',
        marginTop: RFValue(10)
    }
});
export default Empty2;
