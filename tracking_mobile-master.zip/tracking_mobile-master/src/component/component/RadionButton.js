import React, { Component } from "react";
import {Platform, Image, TouchableOpacity, StyleSheet} from "react-native";
import { Footer, FooterTab, Text, Button, Icon, View } from "native-base";
import colors from "../styles/colors/index";
import {RFValue} from "react-native-responsive-fontsize";

class RadioButton extends Component {
    constructor(props) {
        super(props);
        this.state = {
            statRadio: []
        };
    }

    render() {
        return (
            <TouchableOpacity onPress={this.props.onPress}>
                <View style={{flexDirection: "row", marginRight:RFValue(15), justifyContent: 'center'}}>
                    <View style={styles.contentRadio}>
                        {this.props.selected ? (
                            <View
                                style={styles.radio}
                            />
                        ) : null}
                    </View>
                    <Text style={styles.title}> {this.props.name}</Text>
                </View>
            </TouchableOpacity>
        );
    }
}

export default RadioButton;

const styles = StyleSheet.create({
    contentRadio: {
        height: RFValue(15),
        width: RFValue(15),
        borderRadius: 12,
        borderWidth: 2,
        borderColor: colors.green_1st,
        alignItems: "center",
        justifyContent: "center"
    },
    radio:{
        height: RFValue(8),
        width: RFValue(8),
        borderRadius: 6,
        backgroundColor: colors.green_1st
    },
    title:{
        fontSize:RFValue(12),
        color:colors.black_1st,
        textAlign:'left',
        fontFamily:'Roboto-Medium'
    }
})
