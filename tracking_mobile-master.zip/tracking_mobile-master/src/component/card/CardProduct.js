import React, { Component } from "react";
import {View, Text, Image, TouchableNativeFeedback, StyleSheet} from "react-native";
import { Icon } from "native-base";
import colors from "../../component/styles/colors/index";
import PropTypes from "prop-types";
import {RFValue} from "react-native-responsive-fontsize";
import IconMC from "react-native-vector-icons/MaterialCommunityIcons";
import IconAnt from "react-native-vector-icons/AntDesign";
import {convertRp, convertNoRp,  cutString} from "../../component/function/function";

export default class CardProduct extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        const { loading, disabled, handleOnPress } = this.props;
        return (
            <View style={styles.container}>
                <View style={styles.contentImage}>
                    <Image style={styles.imageSparepart} source={this.props.image}/>
                </View>
                <View style={{padding:RFValue(10)}}>
                    <Text style={styles.nameSparepart} numberOfLines={2}>{this.props.name}</Text>
                    <Text style={styles.priceSparepart} numberOfLines={1}>{convertRp(this.props.price)}</Text>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        width: '98%',
        flex:1,
        height: RFValue(180),
        borderRadius: RFValue(5),
        borderWidth:2,
        borderColor:colors.gray_1st,
        marginBottom:RFValue(10),

    },
    contentImage:{
        height:RFValue(100),
        width:'100%',
        borderTopLeftRadius:RFValue(5),
        borderTopRightRadius:RFValue(5)
    },
    imageSparepart:{
        width: '100%',
        height: '100%',
        borderTopLeftRadius:RFValue(5),
        borderTopRightRadius:RFValue(5)
    },
    nameSparepart:{
        marginTop:RFValue(5),
        color:colors.black_1st,
        textAlign:'left',
        fontSize:RFValue(12),
        fontFamily:'Roboto-Medium'
    },
    priceSparepart:{
        marginTop:RFValue(5),
        color:colors.green_1st,
        textAlign:'left',
        fontSize:RFValue(15),
        fontFamily:'Roboto-Medium'
    }


})

CardProduct.propTypes = {
    handleOnPress: PropTypes.func,
    disabled: PropTypes.bool
};
