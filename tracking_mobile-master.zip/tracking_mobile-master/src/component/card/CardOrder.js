import React, { Component } from "react";
import {View, Text, Image, StyleSheet} from "react-native";
import PropTypes from "prop-types";
import {RFValue} from "react-native-responsive-fontsize";
import {convertRp, convertNoRp,  cutString} from "../../component/function/function";
import stylesText from "../styles/styles/stylesText";
import stylesContent from "../styles/styles/stylesContent";

export default class CardOrder extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        const { loading, disabled, handleOnPress } = this.props;
        return (
            <View style={stylesContent.flexRow}>
                <View style={styles.contentImage}>
                    <Image style={stylesContent.image} source={this.props.image}/>
                </View>
                <View style={styles.contentInfo}>
                    <Text style={stylesText.subtitle}>ID 98900</Text>
                    <Text style={stylesText.title} numberOfLines={2}>{this.props.name}</Text>
                    <Text style={stylesText.number}>{convertRp(this.props.price)}</Text>
                    <View style={stylesContent.flexRow}>
                        <Text style={stylesText.time}>10/10/2020</Text>
                        <Text style={[stylesText.time, {marginLeft:RFValue(5)}]}>09:00</Text>
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    contentImage:{
        width:'25%',
    },
    contentInfo:{
        width:'75%',
        paddingLeft:RFValue(10)
    },
})

CardOrder.propTypes = {
    handleOnPress: PropTypes.func,
    disabled: PropTypes.bool
};
