import React, { Component } from "react";
import {View, Text, Image, TouchableNativeFeedback, StyleSheet} from "react-native";
import { Icon } from "native-base";
import colors from "../../component/styles/colors/index";
import PropTypes from "prop-types";
import {RFValue} from "react-native-responsive-fontsize";
import IconMC from "react-native-vector-icons/MaterialCommunityIcons";
import IconAnt from "react-native-vector-icons/AntDesign";
import {convertRp, convertNoRp,  cutString} from "../../component/function/function";

export default class CardBank extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        const { loading, disabled, handleOnPress } = this.props;
        return (
            <View style={styles.container}>
                <View style={styles.contentImage}>
                    <Image style={styles.imageSparepart} source={this.props.image}/>
                </View>
                <View style={{padding:RFValue(10)}}>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        width: '100%',
        height: RFValue(80),
        borderBottomWidth:1,
        borderColor:colors.gray_1st,
        flex:1,
        flexDirection:'row',
    },
    contentImage:{
        height:RFValue(100),
        width:'30%',
        justifyContent:'center',
        alignItems:'center'
    },
    imageSparepart:{
        width: '100%',
        height: '100%',
        resizeMode:'contain'
    },
    nameBank:{
        color:colors.black_1st,
        textAlign:'left',
        fontSize:RFValue(15),
        fontFamily:'Roboto-Medium'
    },
})

CardBank.propTypes = {
    handleOnPress: PropTypes.func,
    disabled: PropTypes.bool
};
