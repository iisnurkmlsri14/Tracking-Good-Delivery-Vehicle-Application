import React, { Component } from "react";
import {View, Text, Image, TouchableNativeFeedback, StyleSheet} from "react-native";
import { Icon } from "native-base";
import colors from "../../component/styles/colors/index";
import PropTypes from "prop-types";
import {RFValue} from "react-native-responsive-fontsize";
import IconMC from "react-native-vector-icons/MaterialCommunityIcons";
import IconAnt from "react-native-vector-icons/AntDesign";
import {convertRp, convertNoRp, cutString, cutRp} from "../../component/function/function";

export default class CardHistoryTopUp extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        const { loading, disabled, handleOnPress } = this.props;
        return (
            <View style={styles.container}>
                <Text style={styles.noOrder}>{this.props.noOrder}</Text>
                <Text style={styles.time}>{this.props.time}</Text>
                <Text style={styles.nominal}>{convertRp(this.props.nominal)}</Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        width: '100%',
        borderBottomWidth:1,
        borderColor:colors.gray_1st,
        flex:1,
        flexDirection:'column',
        paddingHorizontal:RFValue(15),
        paddingVertical:RFValue(15)
    },
    noOrder:{
        color:colors.black_1st,
        textAlign:'left',
        fontSize:RFValue(12),
        fontFamily:'Roboto-Medium'
    },
    time:{
        color:colors.gray_1st,
        textAlign:'left',
        fontSize:RFValue(12),
        fontFamily:'Roboto-Medium'
    },
    nominal:{
        color:colors.green_1st,
        textAlign:'left',
        fontSize:RFValue(15),
        fontFamily:'Roboto-Medium'
    },
})

CardHistoryTopUp.propTypes = {
    handleOnPress: PropTypes.func,
    disabled: PropTypes.bool
};
