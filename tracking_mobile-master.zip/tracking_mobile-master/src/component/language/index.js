let lang = ''
let language = 'IND'
if(language == 'IND'){
    lang = true
} else {
    lang = false
}

export default {
    TopMenu_1 : TopMenu_1 = lang ? 'Pembayaran' : 'Payment',
    TopMenu_2 : TopMenu_2 = lang ? 'Isi Ulang' : 'Top Up',
    TopMenu_3 : TopMenu_3 = lang ? 'Point' : 'Point',
    TabBar_1 : TabBar_1 = lang ? 'Home' : 'Home',
    TabBar_2 : TabBar_2 = lang ? 'Riwayat' : 'History',
    TabBar_3 : TabBar_3 = lang ? 'Saldo' : 'Saldo',
    TabBar_4 : TabBar_4 = lang ? 'Wishlist' : 'Wishlist',
    TabBar_5 : TabBar_5 = lang ? 'Akun' : 'Profile',

    Dashboard_Saldo : Dashboard_Saldo = lang ? 'Saldo Anda' : 'My total balance',
    Dashboard_Rupiah : Dashboard_Rupiah = lang ? 'Rp' : 'RP',

    HomeMenu_1 : HomeMenu_1 = lang ? 'Artikel' : 'Article',
    HomeMenu_2 : HomeMenu_2 = lang ? 'Materi' : 'Module',
    HomeMenu_3 : HomeMenu_3 = lang ? 'Soal-Soal' : 'Exercise',
    HomeMenu_4 : HomeMenu_4 = lang ? 'Tentor' : 'Tentor',
    HomeMenu_5 : HomeMenu_5 = lang ? 'Jadwal Belajar' : 'Schedule',
    HomeMenu_6 : HomeMenu_6 = lang ? 'Lainnya' : 'Other',

    Home_1 : Home_1 = lang ? 'Berita' : 'News',
    Home_2 : Home_2 = lang ? 'Lihat Semua' : 'View All',
    Home_3 : Home_3 = lang ? 'Tentor Populer' : 'Popular Tentor',

    Article_1 : Article_1 = lang ? 'Cari Artikel' : 'Search Article',

    Module_1 : Module_1 = lang ? 'Pilih Jenjang' : 'Pilih Jenjang',
    Module_2 : Module_2 = lang ? 'SD' : 'SD',
    Module_3 : Module_3 = lang ? 'SMP' : 'SMP',
    Module_4 : Module_4 = lang ? 'SMA' : 'SMA',
    Module_5 : Module_5 = lang ? 'Umum' : 'Umum',

    listModule_1 : listModule_1 = lang ? 'Matematika' : 'Matematika',
    listModule_2 : listModule_2 = lang ? 'IPA' : 'IPA',
    listModule_3 : listModule_3 = lang ? 'IPS' : 'IPS',
    listModule_4 : listModule_4 = lang ? 'Bahasa Indonesia' : 'Bahasa Indonesia',
    listModule_5 : listModule_5 = lang ? 'Bahasa Inggris' : 'Bahasa Inggris',
    listModule_6 : listModule_6 = lang ? 'PKN' : 'PKN',
    listModule_7 : listModule_7 = lang ? 'Geografi' : 'Geografi',
    listModule_8 : listModule_8 = lang ? 'Sejarah' : 'Sejarah',
    listModule_9 : listModule_9 = lang ? 'Biologi' : 'Biologi',
    listModule_10 : listModule_10 = lang ? 'Fisika' : 'Fisika',
    listModule_11 : listModule_10 = lang ? 'Agama' : 'Agama',

    Tentor_1 : Tentor_1 = lang ? 'Cari Tentor' : 'Search Tentor',

    Pay_1 : Pay_1 = lang ? 'History Pembayaran' : 'Payment History',
    Pay_2 : Pay_2 = lang ? 'Hapus History' : 'Delete History',

    Profile_1 : Profile_1 = lang ? 'Nama' : 'Name',
    Profile_2 : Profile_2 = lang ? 'Username' : 'Username',
    Profile_3 : Profile_3 = lang ? 'Password' : 'Password',
    Profile_4 : Profile_4 = lang ? 'Email' : 'Email',
    Profile_5 : Profile_5 = lang ? 'Nomor Telepone' : 'Phone Number',
    Profile_6 : Profile_6 = lang ? 'Jenjang' : 'Education Level',
    Profile_7 : Profile_7 = lang ? 'Ubah Password' : 'Change Password',
    Profile_8 : Profile_8 = lang ? 'Jenis Kelamin' : 'Gender',
    Profile_9 : Profile_9 = lang ? 'Keluar' : 'Logout',
    Profile_10 : Profile_10 = lang ? 'Alamat' : 'Address',
}
