import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    ScrollView
} from "react-native";
import {
    Button,Container
} from "native-base";
import {
    TextField,
    FilledTextField,
    OutlinedTextField,
} from 'react-native-material-textfield';
import PasswordInputText from 'react-native-hide-show-password-input';
import colors from "../../component/styles/colors/index";
import { RFPercentage, RFValue } from "react-native-responsive-fontsize";
import CustomHeader from "../../component/header/CustomHeader";
import CustomFooter from "../../component/footer/CustomFooter";
const icon_account = require('../../assets/icon/icon_account.png');

export default class Account extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            dataProfile: [],
        }
    }

    static navigationOptions = {
        header: null
    };

    componentDidMount() {
        AsyncStorage.getItem("dataProfile").then(dataProfile => {
            this.setState({
                dataProfile: JSON.parse(dataProfile),
            })
        });
    }

    render() {
        return (
            <Container style={styles.container}>
                <CustomHeader navigation={this.props.navigation} title='Akun Saya' left={true} right={false}/>
                <ScrollView style={{width:'100%'}}>
                    <View style={styles.content}>
                        <View style={styles.cardInstansi}>
                            <View style={styles.cardName}>
                                <Text style={styles.titleCard}>Nama</Text>
                                <Text style={styles.valueCard}>{this.state.dataProfile.nama}</Text>
                                <Text/>
                                <Text style={styles.titleCard}>Email</Text>
                                <Text style={styles.valueCard}>{this.state.dataProfile.email}</Text>
                            </View>
                            <View style={styles.cardImage}>
                                <View style={styles.circlePhoto}>
                                    <Image source={icon_account} style={styles.img}/>
                                </View>
                            </View>
                        </View>
                    </View>
                </ScrollView>
                <CustomFooter navigation={this.props.navigation} tab="Account" />
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:colors.white_1st,
    },
    content:{
        width:'100%',
        paddingHorizontal:RFValue(15),
        marginTop:RFValue(10)
    },
    title:{
        fontSize:RFValue(13),
        marginBottom:RFValue(5),
        fontFamily:'Roboto-Medium'
    },
    subTitle:{
        fontSize:RFValue(10),
        fontFamily:'Roboto-Light',
        marginTop:RFValue(-3)
    },
    alert:{
        fontSize:RFValue(12),
        fontFamily:'Roboto-Medium',
        marginTop:RFValue(3),
        color: colors.red_1st,
    },
    cardInstansi:{
        marginVertical:RFValue(15),
        backgroundColor:colors.gray_1st,
        borderRadius: RFValue(5),
        flexDirection:'row',
        padding: RFValue(15),
    },
    cardName:{
        width:'70%'
    },
    cardImage:{
        width:'30%',
        alignItems:'flex-end'
    },
    circlePhoto:{
        marginTop:RFValue(10),
        width:RFValue(50),
        height: RFValue(50),
        borderRadius:RFValue(25),
        backgroundColor:colors.green_1st,
        justifyContent:'center',
        alignItems: 'center'
    },
    img:{
        width:'80%',
        height: '80%',
        resizeMode:'contain',
    },
    titleCard:{
        fontSize:RFValue(13),
        fontFamily:'Roboto-Light'
    },
    valueCard:{
        fontSize:RFValue(13),
        fontFamily:'Roboto-Medium',
        color:colors.green_1st
    },
    edit:{
        fontSize:RFValue(13),
        fontFamily:'Roboto-Medium',
        color:colors.green_1st,
        textAlign:'right'
    },
    border:{
        borderBottomWidth:2,
        borderColor: colors.gray_1st,
        paddingVertical:RFValue(8),
    },
    logout:{
        marginTop:RFValue(10),
        fontSize:RFValue(13),
        fontFamily:'Roboto-Medium',
        color:colors.red_1st,
        textAlign:'center'
    },
    contentOther:{
        flexDirection: 'row',
        borderBottomWidth: 2,
        borderColor: colors.gray_1st,
        paddingVertical:RFValue(10)
    },
    iconOther:{
        width:RFValue(40),
        height:RFValue(40),
        borderRadius:RFValue(20),
        backgroundColor:colors.gray_1st,
        justifyContent:'center',
        alignItems: 'center'
    },
    textOther:{
        paddingLeft:RFValue(10)
    }
});

