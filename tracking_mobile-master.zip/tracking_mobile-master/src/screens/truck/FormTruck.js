import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    Dimensions,
    FlatList,
    ImageBackground, ScrollView
} from "react-native";
import {
    Button,
    Container, Icon, Textarea
} from "native-base";
import Dialog, {
    DialogTitle,
    SlideAnimation,
    DialogContent,
    DialogButton
} from "react-native-popup-dialog";
import CustomHeader from "../../component/header/CustomHeader";
import Loader from "../../component/loader/loader";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../../component/styles/colors/index";
import {TextField} from "react-native-material-textfield";
import stylesContent from "../../component/styles/styles/stylesContent";
import stylesText from "../../component/styles/styles/stylesText";
import PasswordInputText from "react-native-hide-show-password-input";
import GlobalConfig from "../../component/server/GlobalConfig";
var that;

export default class FormTruck extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading:false,
        };
    }

    static navigationOptions = {
        header: null
    };

    Alert(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => console.log('Cancel Pressed'), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }

    Close(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => this.props.navigation.navigate('Truck'), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }


    navigationToScreen(){
        if(this.state.nama_truck == '' || this.state.nama_truck == undefined){
            this.Alert('Masukkan Nama Kendaran')
        } else if(this.state.nopol == '' || this.state.nopol == undefined){
            this.Alert('Masukkan No Kendaraan')
        } else {
            this.save()
        }
    }

    save(){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'addTruck';
        var formData = new FormData();
        formData.append("nama_truck", this.state.nama_truck)
        formData.append("nopol", this.state.nopol)

        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        loading:false
                    })
                    setTimeout(() =>
                            this.Close('Truck Berhasil Ditambahkan')
                        , 312);
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    render() {
        that=this;
        return (
            <Container style={stylesContent.container}>
                <Loader loading={this.state.loading} />
                <CustomHeader navigation={this.props.navigation} title='Form Truck' left={true} right={false}/>
                <ScrollView style={{width:'100%'}}>
                    <View style={stylesContent.content}>
                        <View style={{width:'100%', marginTop: RFValue(10)}}>
                            <TextField
                                label='Nama Truck'
                                formatText={this.formatText}
                                onSubmitEditing={this.onSubmit}
                                ref={this.fieldRef}
                                tintColor={colors.green_1st}
                                fontSize={16}
                                labelFontSize={13}
                                value={this.state.nama_truck}
                                onChangeText={(text) => this.setState({nama_truck: text})}
                            />
                            <TextField
                                label='No Kendaraan'
                                formatText={this.formatText}
                                onSubmitEditing={this.onSubmit}
                                ref={this.fieldRef}
                                tintColor={colors.green_1st}
                                fontSize={16}
                                labelFontSize={13}
                                value={this.state.nopol}
                                onChangeText={(text) => this.setState({nopol: text})}
                            />
                        </View>
                    </View>
                </ScrollView>
                <View style={{paddingHorizontal:RFValue(15)}}>
                    <TouchableOpacity style={stylesContent.btnPrimary} onPress={()=>this.navigationToScreen()}>
                        <Text style={stylesText.btnTextPrimary}>Tambah</Text>
                    </TouchableOpacity>
                </View>
            </Container>
        )
    }
}
