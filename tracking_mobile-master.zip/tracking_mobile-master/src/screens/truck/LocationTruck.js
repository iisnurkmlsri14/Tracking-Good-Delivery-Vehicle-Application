import React, { Component } from "react";

import {
    Alert,
    StatusBar,
    View,
    Image,
    ScrollView,
    TouchableOpacity,
    ImageBackground,
    AsyncStorage,
    PermissionsAndroid,
    Platform,
    Dimensions,
    StyleSheet
} from "react-native";
import {
    Container,
    Icon,
    Item,
    Input,
    Button,
    Card,
    CardItem,
    Text,
    Header,
    Left,
    Title,
    Right,
    Body,
} from "native-base";
import {RFValue} from "react-native-responsive-fontsize";
const width = Dimensions.get('window').width
import MapView from 'react-native-maps'
import { Marker } from 'react-native-maps';
import Loader from "../../component/loader/loader";
import CustomHeader from "../../component/header/CustomHeader";
import GlobalConfig from "../../component/server/GlobalConfig";
import stylesContent from "../../component/styles/styles/stylesContent";
import MyView from "../../component/view/MyView";
const marker = require("../../assets/icon/marker.png");

export default class LocationTruck extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            // latitude: -7.2576719,
            // longitude: 112.7471782,
            seconds:0
        }
    }
    static navigationOptions = {
        header: null
    };

    componentDidMount() {
        this.setState({
            latitude : -7.2576719,
            longitude: 112.7471782,
        })
        AsyncStorage.getItem("IdTruck").then(IdTruck => {
            this.setState({
                idTruck: JSON.parse(IdTruck),
            })
            this.loadLocation()
        });
        this.interval = setInterval(() => this.loadLocation(), 5000);
    }

    loadLocation(){
        // this.setState({
        //     loading:true
        // })
        this.setState(prevState => ({
            seconds: prevState.seconds + 1
        }));
        var url = GlobalConfig.URL_SERVER + 'getGPSOne';
        var formData = new FormData();
        formData.append("id_truck", this.state.idTruck)
        // formData.append("id_order", 0)
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                this.setState({
                    loading:false,
                    longitude:parseFloat(response.longitude),
                    latitude:parseFloat(response.latitude),
                })
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    render() {
        return (
            <Container style={styles.MainContainer}>
                <Loader loading={this.state.loading} />
                <CustomHeader navigation={this.props.navigation} title='Lokasi Truck' left={true} right={false}/>
                <Container>
                    <MapView
                        // provider={PROVIDER_GOOGLE}
                        style={styles.mapStyle}
                        showsUserLocation={false}
                        zoomEnabled={true}
                        zoomControlEnabled={true}
                        initialRegion={{
                            latitude: this.state.loading ? -7.2576719 : this.state.latitude,
                            longitude: this.state.loading ? 112.7471782 : this.state.longitude,
                            latitudeDelta: 0.0922,
                            longitudeDelta: 0.0421,
                        }}>

                        <Marker
                            coordinate={{ latitude: this.state.loading ? -7.2576719 : this.state.latitude, longitude: this.state.loading ? 112.7471782 : this.state.longitude}}
                            title={"JavaTpoint"}
                            description={"Java Training Institute"}
                        >
                            <Image source={marker} style={stylesContent.marker} />
                        </Marker>
                    </MapView>
                </Container>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    MainContainer: {
        flex:1
    },
    mapStyle: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
    },
})
