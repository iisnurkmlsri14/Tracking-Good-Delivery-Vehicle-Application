import React, { Component } from "react";

import {
    Alert,
    StatusBar,
    View,
    Image,
    ScrollView,
    TouchableOpacity,
    ImageBackground,
    AsyncStorage,
    PermissionsAndroid,
    Platform,
    Dimensions,
    StyleSheet, FlatList
} from "react-native";
import {
    Container,
    Icon,
    Item,
    Input,
    Button,
    Card,
    CardItem,
    Text,
    Header,
    Left,
    Title,
    Right,
    Body,
} from "native-base";
import {RFValue} from "react-native-responsive-fontsize";
const width = Dimensions.get('window').width
import MapView from 'react-native-maps';
import { Marker } from 'react-native-maps';
import Loader from "../../component/loader/loader";
import CustomHeader from "../../component/header/CustomHeader";
import GlobalConfig from "../../component/server/GlobalConfig";
import stylesContent from "../../component/styles/styles/stylesContent";
import stylesText from "../../component/styles/styles/stylesText";
const iconMarker = require("../../assets/icon/marker.png");
import colors from "../../component/styles/colors/index"


export default class LocationTruckOrder extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            marker:[],
        }
    }
    static navigationOptions = {
        header: null
    };

    componentDidMount() {
        this.setState({
            lastLongitude: 112.7471782,
            lastLatitude: -7.2576719,
            marker:[],
        })
        AsyncStorage.getItem("IdOrderCur").then(IdOrderCur => {
            this.setState({
                idOrder: JSON.parse(IdOrderCur),
            })
            this.loadLocation()
        });
    }

    Alert(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => console.log('Cancel Pressed'), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }

    loadLocation(){
        // this.setState({
        //     loading:true
        // })
        var url = GlobalConfig.URL_SERVER + 'getGPSHistory';
        var formData = new FormData();
        // formData.append("id_truck", this.state.idTruck)
        formData.append("id_order", this.state.idOrder)
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                this.setState({
                    loading:false,
                    // data:response.data
                    lastLongitude: parseFloat(response.last.longitude),
                    lastLatitude: parseFloat(response.last.latitude),
                    marker:response.data
                })
                // console.warn(this.state.lastLongitude)
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }


    render() {
        return (
            <Container style={styles.MainContainer}>
                <Loader loading={this.state.loading} />
                <CustomHeader navigation={this.props.navigation} title='Lokasi Truck' left={true} right={false}/>
                <Container>

                <MapView
                    style={styles.mapStyle}
                    showsUserLocation={false}
                    zoomEnabled={true}
                    zoomControlEnabled={true}
                    // initialRegion={{
                    //     latitude: this.state.loading ? -7.2576719 : this.state.latitude,
                    //     longitude: this.state.loading ? 112.7471782 : this.state.longitude,
                    //     latitudeDelta: 0.0922,
                    //     longitudeDelta: 0.0421,
                    // }}>
                    initialRegion={{
                        latitude: this.state.lastLatitude,
                        longitude: this.state.lastLongitude,
                        latitudeDelta: 0.0922,
                        longitudeDelta: 0.0421,
                    }}>

                    {this.state.marker.map(marker => (
                        <Marker
                            coordinate={{latitude: parseFloat(marker.latitude), longitude : parseFloat(marker.longitude)}}
                            // title={marker.title}
                        >
                            <View style={styles.curr}/>
                            {/*<Image source={iconMarker} style={{height: 10, width:10 }} />*/}
                        </Marker>
                    ))}
                </MapView>
                </Container>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    MainContainer: {
        flex:1
    },
    mapStyle: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
    },
    curr:{
        width:5,
        height:5,
        borderRadius:10,
        backgroundColor:colors.red_1st
    }
})
