import paho.mqtt.client as mqtt
import mysql.connector
import time
import datetime
import requests

def datamasukan():
def simpanId(mosq, obj, msg):
kata = msg.payload
kata = kata.decode("utf-8")
words = kata.split(",")
print(words)
lon=words[0]
lat = words[1]
if (lon!=0 or lat !=0):
simpanDatabase(lon,lat)

#(str(lon)!="nan" or str(lat) !="nan") and
def on_message(mosq, obj, msg):
pass

def simpanDatabase(lng,lat):

API_ENDPOINT = "http://trackingsistem.kadosurabaya.com/api/insertGPS"
dt = datetime.datetime.now()
waktu = dt.strftime("%Y-%m-%d %H:%M:%S")

data = {
        'id_truck': '2',
        'time': waktu,
        'longitude': lng,
        'latitude': lat
}

requests.post(url = API_ENDPOINT, data = data)

mqttc = mqtt.Client()
mqttc.message_callback_add("/gps/data/", simpanId)
mqttc.connect("34.70.52.209", 1883, 60)
mqttc.subscribe("/gps/#", 0)
mqttc.loop_forever()

datamasukan()
