import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    Dimensions,
    FlatList,
    ImageBackground, ScrollView
} from "react-native";
import {
    Body,
    Button,
    Container, Fab, Header, Icon, Left, Right, Textarea
} from "native-base";
import CustomHeader from "../../component/header/CustomHeader";
import Loader from "../../component/loader/loader";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../../component/styles/colors/index";
import stylesText from "../../component/styles/styles/stylesText";
import stylesContent from "../../component/styles/styles/stylesContent";
import GlobalConfig from "../../component/server/GlobalConfig";
import IconEvil from "react-native-vector-icons/EvilIcons";
import AntIcon from "react-native-vector-icons/AntDesign";
const type_2 = require("../../assets/icon/1x20.jpg");
var that;

class ListTruck extends React.PureComponent {
    render() {
        let index = this.props.index + 1
        return (
            <View style={stylesContent.cardBottomWidth}>
                <View style={{width:'8%'}}>
                    <Text style={stylesText.textIndex}>{index}.</Text>
                </View>
                <View style={{width:'87%'}}>
                    <Text style={stylesText.textName} numberOfLines={2}>{this.props.data.nama_truck}, TRUCK-000{this.props.data.id}</Text>
                    <Text style={stylesText.textEmail} numberOfLines={2}>Nopol : {this.props.data.nopol}</Text>
                    <View style={{flexDirection:'row', marginTop:RFValue(5)}}>
                        <TouchableOpacity style={styles.btnDetail} onPress={() => that.navigateToScreen(this.props.data.id)}>
                            <Text style={styles.viewDetail}>Detail Lokasi</Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <TouchableOpacity style={{width:'5%'}} onPress={()=> that.delete(this.props.data.id)}>
                    <IconEvil name="trash" size={RFValue(20)} style={{color:colors.green_1st}}/>
                </TouchableOpacity>
            </View>
        )
    }
}

export default class Truck extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading:false,
            listTruck:[],
        };
    }

    static navigationOptions = {
        header: null
    };

    componentDidMount() {
        this.loadTruck()
        this._onFocusListener = this.props.navigation.addListener(
            "didFocus",
            payload => {
                this.loadTruck()
            }
        );
    }

    loadTruck(){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'getAllTruck';
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'GET',

        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        listTruck: response.data,
                        loading:false
                    });
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    delete(id){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'deleteTruck';
        var formData = new FormData();
        formData.append("id", id)
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        loading:false
                    })
                    setTimeout(() =>
                            this.Alert('Truck Berhasil Dihapus')
                        , 312);
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    Alert(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => this.componentDidMount(), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }

    addTruck(root){
        this.props.navigation.navigate(root)
    }

    navigateToScreen(id){
        AsyncStorage.setItem('IdTruck', JSON.stringify(id)).then(() => {
            this.props.navigation.navigate("LocationTruck");
        })
    }

    navigateToScreenAll(id){
        AsyncStorage.setItem('IdTruck', JSON.stringify(1)).then(() => {
            this.props.navigation.navigate("LocationTruckAll");
        })
    }

    _renderTruck = ({ item, index }) => <ListTruck data={item} index={index}/>;

    render() {
        that=this;
        let filter = this.state.filter
        return (
            <Container style={stylesContent.container}>
                <Loader loading={this.state.loading} />
                <CustomHeader navigation={this.props.navigation} title='Kelola Truck' left={true} right={false}/>
                <ScrollView style={{width:'100%'}}>
                    <View style={{paddingHorizontal:RFValue(15), paddingVertical:RFValue(10), flexDirection:'row'}}>
                        <View style={{width:'65%'}}>
                            <Text style={stylesText.titleText}>Semua Truck</Text>
                        </View>
                        <View style={{width:'35%', justifyContent:'center'}}>
                            <TouchableOpacity style={styles.btnDetail} onPress={() => this.navigateToScreenAll()}>
                                <Text style={styles.viewDetailOrder}>Lihat Lokasi</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                    <View style={styles.contentArmada}>
                        <TouchableOpacity style={styles.contentType} onPress={() => this.filterTruck('Type2')}>
                            <Image source={type_2} style={styles.imageTruckType}/>
                        </TouchableOpacity>
                    </View>
                    <View style={{paddingHorizontal:RFValue(15), paddingVertical:RFValue(10)}}>
                        <Text style={stylesText.titleText}>List Truck</Text>
                        <Text style={stylesText.subtitleText}>List Semua Truck</Text>
                    </View>
                    <View style={stylesContent.border}/>
                    <FlatList
                        data={this.state.listTruck}
                        renderItem={this._renderTruck}
                        keyExtractor={(item, index) => index.toString()}
                    />
                </ScrollView>
                <Fab
                    active={false}
                    direction="up"
                    containerStyle={{}}
                    style={{ backgroundColor: colors.green_1st, marginBottom: RFValue(25) }}
                    position="bottomRight"
                    onPress={() => this.addTruck('FormTruck')}
                >
                    <AntIcon
                        name="plus"
                        style={{
                            fontSize: RFValue(20),
                            fontWeight: "bold",
                        }}
                    />
                </Fab>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    btnDetail:{
        backgroundColor:colors.green_1st,
        paddingVertical: RFValue(1),
        paddingHorizontal:RFValue(10),
        borderRadius:RFValue(5),
        justifyContent:'center',
        alignItems:'center'
    },
    viewDetail:{
        fontSize:RFValue(10),
        fontFamily:'Roboto-Medium',
        color:colors.white_1st
    },
    viewDetailOrder:{
        fontSize:RFValue(12),
        fontFamily:'Roboto-Medium',
        color:colors.white_1st,
        marginVertical:RFValue(6)
    },
    contentArmada:{
        paddingTop:RFValue(5),
        borderBottomWidth: 2,
        borderColor: colors.gray_1st,
        alignItems:'center',
        paddingHorizontal:RFValue(15),
        marginBottom:RFValue(10)
    },
    imageTruckType:{
        width:'100%',
        height:100,
        resizeMode: 'contain'
    },
    contentType:{
        width:'60%',
        paddingHorizontal:RFValue(5),
    },
});
