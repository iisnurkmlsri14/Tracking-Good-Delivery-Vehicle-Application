import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    Dimensions,
    FlatList,
    ImageBackground, ScrollView
} from "react-native";
import {
    Button,
    Container, Form, Icon, Picker, Textarea
} from "native-base";
import Dialog, {
    DialogTitle,
    SlideAnimation,
    DialogContent,
    DialogButton
} from "react-native-popup-dialog";
import CustomHeader from "../../component/header/CustomHeader";
import Loader from "../../component/loader/loader";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../../component/styles/colors/index";
import {TextField} from "react-native-material-textfield";
import stylesContent from "../../component/styles/styles/stylesContent";
import stylesText from "../../component/styles/styles/stylesText";
import PasswordInputText from "react-native-hide-show-password-input";
import GlobalConfig from "../../component/server/GlobalConfig";
import IconEvil from "react-native-vector-icons/EvilIcons";
import HandleBack from "../../component/backHandler/HandleBack";
var that;

export default class FormOrder extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading:false,
            modalOrder:false,
            listTruck:[],
            listCustomers:[],
            listOrder:[],
            customers:1,
        };
    }

    static navigationOptions = {
        header: null
    };

    componentDidMount() {
        this.loadTruck()
        this.loadCustomers()
        this._onFocusListener = this.props.navigation.addListener(
            "didFocus",
            payload => {
                this.loadTruck()
                this.loadCustomers()
            }
        );
    }

    loadTruck(){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'getAllTruck';
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'GET',

        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        listTruck: response.data,
                        loading:false
                    });
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    loadCustomers(){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'getAllRegister';
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'GET',

        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        listCustomers: response.data,
                        loading:false
                    });
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    Alert(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => console.log('Cancel Pressed'), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }

    Close(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => this.props.navigation.navigate('Order'), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }


    navigationToScreen(){
        if(this.state.truck == '' || this.state.truck == undefined){
            this.Alert('Masukkan Truck')
        } else if(this.state.nama_kurir == '' || this.state.nama_kurir == undefined){
            this.Alert('Masukkan Nama Kurir')
        } else if(this.state.listOrder == '' || this.state.listOrder == undefined || this.state.listOrder == null) {
            this.Alert('Masukkan Order Customers')
        } else {
            this.save()
        }
    }

    save(){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'addOrder';
        var formData = new FormData();
        formData.append("id_truck", this.state.truck)
        formData.append("nama_kurir", this.state.nama_kurir)
        formData.append("detail", JSON.stringify(this.state.listOrder))

        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        loading:false
                    })
                    setTimeout(() =>
                            this.Close('Order Berhasil Ditambahkan')
                        , 312);
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    addCustomersValidasi(){
       if(this.state.customers == ''){
            this.Alert('Masukkan Customers')
        } else if(this.state.nama_barang == '' || this.state.nama_barang == undefined){
            this.Alert('Masukkan Nama Barang')
        } else if(this.state.destinasion == '' || this.state.destinasion == undefined) {
            this.Alert('Masukkan Tujuan Pengiriman')
        } else {
            this.addCustomers()
        }
    }

    addCustomers(){
        this.setState({
            modalOrder:false
        })

        let customers = this.state.customers;
        let nama_barang = this.state.nama_barang;
        let destinasion = this.state.destinasion;

        var temp = {'id_customers': customers, 'nama_barang': nama_barang, 'destinasion' : destinasion};
        var data = this.state.listOrder;
        data.push(temp);

        this.setState({
            listOrder:data,
            customers:'',
            nama_barang:'',
            destinasion:'',
        })
    }

    onBack = () => {
        if(this.state.modalOrder){
            this.setState({
                modalOrder:false
            })
        } else {
            this.props.navigation.goBack()
        }
        return true;
    }

    render() {
        that=this;

        let listTruck = this.state.listTruck.map( (s, i) => {
            return <Picker.Item key={i} value={s.id} label={s.nama_truck + " : " + s.nopol}/>
        });

        let listCustomers = this.state.listCustomers.map( (s, i) => {
            return <Picker.Item key={i} value={s.id} label={s.id + " - " + s.nama}/>
        });

        return (
            <Container style={stylesContent.container}>
                <HandleBack onBack={this.onBack}>
                <Loader loading={this.state.loading} />
                <CustomHeader navigation={this.props.navigation} title='Form Order' left={true} right={false}/>
                <ScrollView style={{width:'100%'}}>
                    <View style={{paddingHorizontal: RFValue(15)}}>
                        <View style={{width:'100%', marginTop: RFValue(10)}}>
                            <Text style={styles.choose}>Pilih Truck</Text>
                            <Form style={styles.borderPicker}>
                                <Picker
                                    mode="dropdown"
                                    iosIcon={<Icon name={"ios-arrow-down"} style={styles.iconDropdown}/>}
                                    style={{ width: '100%', height:RFValue(35)}}
                                    itemTextStyle={{ fontSize: 18, color: colors.black_1st }}
                                    placeholder="Pilih Truck"
                                    textStyle= {styles.placeholder}
                                    placeholderStyle={styles.placeholder}
                                    placeholderIconColor={{color: colors.gray_2st}}
                                    selectedValue={this.state.truck}
                                    onValueChange={(itemValue) => this.setState({truck:itemValue})}>
                                    {listTruck}
                                </Picker>
                            </Form>
                            <TextField
                                label='Nama Kurir'
                                formatText={this.formatText}
                                onSubmitEditing={this.onSubmit}
                                ref={this.fieldRef}
                                tintColor={colors.green_1st}
                                fontSize={16}
                                labelFontSize={13}
                                value={this.state.nama_kurir}
                                onChangeText={(text) => this.setState({nama_kurir: text})}
                            />
                        </View>
                        <View style={{paddingVertical:RFValue(10), flexDirection:'row'}}>
                            <View style={{width:'65%'}}>
                                <Text style={stylesText.titleText}>Semua Order</Text>
                            </View>
                            <View style={{width:'35%', justifyContent:'center'}}>
                                <TouchableOpacity style={styles.btnDetail} onPress={() => this.setState({
                                    modalOrder : true
                                })}>
                                    <Text style={styles.viewDetailOrder}>Tambah Order</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                    <View style={stylesContent.border}/>

                    {this.state.listOrder.map((listOrder, index) => (
                        <View key={index} style={{ backgroundColor: colors.gray }}>
                            <View style={stylesContent.cardBottomWidth}>
                                <View style={{width:'8%'}}>
                                    <Text style={stylesText.textIndex}>{index+1}.</Text>
                                </View>
                                <View style={{width:'92%'}}>
                                    <Text style={stylesText.textName} numberOfLines={2}>CS-000{this.state.listOrder[index].id_customers}</Text>
                                    <Text style={stylesText.subtitleText} numberOfLines={2}>Nama Barang : {this.state.listOrder[index].nama_barang}</Text>
                                    <Text style={stylesText.subtitleText} numberOfLines={2}>Tujuan Pengiriman : {this.state.listOrder[index].destinasion}</Text>
                                </View>
                            </View>
                        </View>
                    ))}
                </ScrollView>
                <View style={{paddingHorizontal:RFValue(15)}}>
                    <TouchableOpacity style={stylesContent.btnPrimary} onPress={()=>this.navigationToScreen()}>
                        <Text style={stylesText.btnTextPrimary}>Tambah</Text>
                    </TouchableOpacity>
                </View>
                <View style={{ width: '100%', position: "absolute"}}>
                    <Dialog
                        visible={this.state.modalOrder}
                        dialogAnimation={
                            new SlideAnimation({
                                slideFrom: "bottom"
                            })
                        }
                        dialogStyle={{ position: "absolute", width:'80%'}}
                        onTouchOutside={() => {
                            this.setState({ modalOrder: false });
                        }}
                    >
                        <DialogContent>
                            {
                                <View>
                                    <View style={{marginTop:RFValue(10), alignItems:'center', marginBottom: RFValue(15)}}>
                                        <Text style={stylesText.title}>Tambah Order</Text>
                                    </View>
                                    <Text style={styles.choose}>Pilih Customers</Text>
                                    <Form style={styles.borderPicker}>
                                        <Picker
                                            mode="dropdown"
                                            iosIcon={<Icon name={"ios-arrow-down"} style={styles.iconDropdown}/>}
                                            style={{ width: '100%', height:RFValue(35)}}
                                            itemTextStyle={{ fontSize: 18, color: colors.black_1st }}
                                            placeholder="Pilih Customers"
                                            textStyle= {styles.placeholder}
                                            placeholderStyle={styles.placeholder}
                                            placeholderIconColor={{color: colors.gray_2st}}
                                            selectedValue={this.state.customers}
                                            onValueChange={(itemValue) => this.setState({customers:itemValue})}>
                                            {listCustomers}
                                        </Picker>
                                    </Form>
                                    <TextField
                                        label='Nama Barang'
                                        formatText={this.formatText}
                                        onSubmitEditing={this.onSubmit}
                                        ref={this.fieldRef}
                                        tintColor={colors.green_1st}
                                        fontSize={16}
                                        labelFontSize={13}
                                        value={this.state.nama_barang}
                                        onChangeText={(text) => this.setState({nama_barang: text})}
                                    />
                                    <TextField
                                        label='Tujuan Pengiriman'
                                        formatText={this.formatText}
                                        onSubmitEditing={this.onSubmit}
                                        ref={this.fieldRef}
                                        tintColor={colors.green_1st}
                                        fontSize={16}
                                        labelFontSize={13}
                                        value={this.state.destinasion}
                                        onChangeText={(text) => this.setState({destinasion: text})}
                                    />
                                    <TouchableOpacity style={stylesContent.btnPrimaryModal} onPress={()=>this.addCustomersValidasi()}>
                                        <Text style={stylesText.btnTextPrimary}>Tambah</Text>
                                    </TouchableOpacity>
                                </View>
                            }
                        </DialogContent>
                    </Dialog>
                </View>
                </HandleBack>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    iconDropdown:{
        color: colors.gray_2st,
        fontSize:RFValue(12),
    },
    placeholder:{
        color: colors.black_1st,
        fontSize:RFValue(12),
        borderRadius:RFValue(10),
        fontFamily: 'Roboto-Light',
    },
    borderPicker:{
        borderRadius: RFValue(5),
        height:35,
        width:'100%',
        borderColor: colors.gray_2st,
        borderWidth: 1,
        justifyContent:'center'
    },
    choose:{
        color: colors.gray_3st,
        fontSize:RFValue(11),
        fontFamily: 'Roboto-Medium',
        marginBottom:RFValue(5)
    },
    btnDetail:{
        backgroundColor:colors.green_1st,
        paddingVertical: RFValue(1),
        paddingHorizontal:RFValue(10),
        borderRadius:RFValue(5),
        justifyContent:'center',
        alignItems:'center'
    },
    viewDetailOrder:{
        fontSize:RFValue(12),
        fontFamily:'Roboto-Medium',
        color:colors.white_1st,
        marginVertical:RFValue(6)
    },
})
