import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    Dimensions,
    FlatList,
    ImageBackground, ScrollView
} from "react-native";
import {
    Button,
    Container, Icon, Textarea, Fab, Left, Body, Right, Header, Form, Picker
} from "native-base";
import CustomHeader from "../../component/header/CustomHeader";
import Loader from "../../component/loader/loader";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../../component/styles/colors/index";
import MyView from "../../component/view/MyView";
var that;
import AntIcon from "react-native-vector-icons/AntDesign"
import GlobalConfig from "../../component/server/GlobalConfig";
import stylesContent from "../../component/styles/styles/stylesContent";
import stylesText from "../../component/styles/styles/stylesText";
import {TextField} from "react-native-material-textfield";
import Dialog, {DialogContent, SlideAnimation} from "react-native-popup-dialog";
import HandleBack from "../../component/backHandler/HandleBack";
const back = require("../../assets/icon/icon_back.png");
const troli_order = require("../../assets/icon/icon_troli_order.png");
export default class OrderDetail extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading:false,
            dataOrder:[],
            modalInput:false
        };
    }

    static navigationOptions = {
        header: null
    };

    navigationScreen(route){
        this.props.navigation.navigate(route)
    }

    componentDidMount() {
        AsyncStorage.getItem("dataOrderCS").then(dataOrderCS => {
            this.setState({
                dataOrder: JSON.parse(dataOrderCS),
            })
        });
    }

    Alert(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => this.componentDidMount(), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }

    navigationToScreen(id){
        AsyncStorage.setItem('IdOrderCur', JSON.stringify(id)).then(() => {
            this.props.navigation.navigate("LocationTruckOrder");
        })
    }

    addSubmitVerifikasi(){
        if(this.state.note == '' || this.state.note == undefined){
            this.Alert('Masukkan Catatan')
        } else {
            this.addSubmit()
        }
    }

    Close(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => this.props.navigation.navigate('OrderHistoryCS'), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }

    addSubmit(){
        this.setState({
            loading:true,
            modalInput:false
        })
        var url = GlobalConfig.URL_SERVER + 'verifikasiOrder';
        var formData = new FormData();
        formData.append("id", this.state.dataOrder.id)
        formData.append("id_order", this.state.dataOrder.id_order)
        formData.append("note", this.state.note)

        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        loading:false
                    })
                    setTimeout(() =>
                            this.Close('Verifikasi Berhasil')
                        , 312);
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    onBack = () => {
        if(this.state.modalInput){
            this.setState({
                modalInput:false
            })
        } else {
            this.props.navigation.goBack()
        }
        return true;
    }

    render() {
        that=this;
        return (
            <Container style={stylesContent.container}>
                <HandleBack onBack={this.onBack}>
                <Loader loading={this.state.loading} />
                <Header style={styles.header}>
                    <Left style={{ flex: 1}}>
                        <TouchableOpacity
                            transparent
                            onPress={()=> this.props.navigation.goBack()}
                            style={styles.btnBack}
                        >
                            <Image source={back} style={styles.iconMenu}/>
                        </TouchableOpacity>
                    </Left>
                    <Body style={{ flex:3, alignItems:'center'}}>
                        <Text style={styles.title}>Detail Order</Text>
                    </Body>
                    <Right style={{ flex: 1}}>
                        <TouchableOpacity
                            transparent
                            onPress={()=> this.navigationToScreen(this.state.dataOrder.id_order)}
                            style={styles.btnBack}
                        >
                            <Image source={troli_order} style={styles.iconHistory}/>
                        </TouchableOpacity>
                    </Right>
                </Header>
                <ScrollView>
                    <View style={{paddingHorizontal: RFValue(15), marginTop:RFValue(20)}}>
                        <Text style={styles.choose}>Pilih Truck</Text>
                        <Text style={styles.value}>ORDER-000{this.state.dataOrder.id_order}</Text>
                        <Text style={styles.choose}>Barang</Text>
                        <Text style={styles.value}>{this.state.dataOrder.nama_barang}</Text>
                        <Text style={styles.choose}>Tujuan Pengiriman</Text>
                        <Text style={styles.value}>{this.state.dataOrder.destinasion}</Text>
                    </View>
                </ScrollView>
                <View style={{paddingHorizontal:RFValue(15)}}>
                    <TouchableOpacity style={stylesContent.btnPrimary} onPress={() => this.setState({
                        modalInput : true
                    })}>
                        <Text style={stylesText.btnTextPrimary}>BARANG SUDAH DITERIMA</Text>
                    </TouchableOpacity>
                </View>

                <View style={{ width: '100%', position: "absolute"}}>
                    <Dialog
                        visible={this.state.modalInput}
                        dialogAnimation={
                            new SlideAnimation({
                                slideFrom: "bottom"
                            })
                        }
                        dialogStyle={{ position: "absolute", width:'80%'}}
                        onTouchOutside={() => {
                            this.setState({ modalInput: false });
                        }}
                    >
                        <DialogContent>
                            {
                                <View>
                                    <View style={{marginTop:RFValue(10), alignItems:'center', marginBottom: RFValue(15)}}>
                                        <Text style={stylesText.title}>Verifikasi Order</Text>
                                    </View>
                                    <TextField
                                        label='Note'
                                        formatText={this.formatText}
                                        onSubmitEditing={this.onSubmit}
                                        ref={this.fieldRef}
                                        tintColor={colors.green_1st}
                                        fontSize={16}
                                        labelFontSize={13}
                                        multiline={true}
                                        value={this.state.note}
                                        onChangeText={(text) => this.setState({note: text})}
                                    />
                                    <TouchableOpacity style={stylesContent.btnPrimaryModal} onPress={()=>this.addSubmitVerifikasi()}>
                                        <Text style={stylesText.btnTextPrimary}>KIRIM</Text>
                                    </TouchableOpacity>
                                </View>
                            }
                        </DialogContent>
                    </Dialog>
                </View>
                </HandleBack>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    title: {
        fontSize:RFValue(17),
        color:colors.white_1st,
        fontFamily: 'Roboto-Medium',
    },
    iconSearch: {
        width:'7%',
        color:colors.gray_1st,
        fontSize:RFValue(15),
    },
    btnBack: {
        width:RFValue(30),
        height:RFValue(30),
        justifyContent:'center',
        alignItems:'center'
    },
    iconMenu:{
        width:RFValue(20),
        height: RFValue(20),
    },
    iconHistory:{
        width:RFValue(30),
        height: RFValue(30),
    },
    header: {
        backgroundColor: colors.green_1st
    },
    choose:{
        color: colors.gray_3st,
        fontSize:RFValue(15),
        fontFamily: 'Roboto-Medium',
        marginBottom:RFValue(2)
    },
    value:{
        color: colors.black_1st,
        fontSize:RFValue(15),
        fontFamily: 'Roboto-Medium',
        marginBottom:RFValue(5)
    },
});

