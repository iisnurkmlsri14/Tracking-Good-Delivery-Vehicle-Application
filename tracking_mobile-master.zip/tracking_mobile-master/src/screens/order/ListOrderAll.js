import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    Dimensions,
    FlatList,
    ImageBackground, ScrollView
} from "react-native";
import {
    Button,
    Container, Icon, Textarea, Fab, Left, Body, Right, Header
} from "native-base";
import CustomHeader from "../../component/header/CustomHeader";
import Loader from "../../component/loader/loader";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../../component/styles/colors/index";
import MyView from "../../component/view/MyView";
var that;
import AntIcon from "react-native-vector-icons/AntDesign"
import GlobalConfig from "../../component/server/GlobalConfig";
import stylesContent from "../../component/styles/styles/stylesContent";
import stylesText from "../../component/styles/styles/stylesText";
import CustomFooter from "../../component/footer/CustomFooter";
import Empty from "../../component/empty/empty";
const back = require("../../assets/icon/icon_back.png");
const troli_order = require("../../assets/icon/icon_troli_order.png");

class ListOrder extends React.PureComponent {
    render() {
        let index = this.props.index + 1
        return (
            <TouchableOpacity style={stylesContent.cardBottomWidth} onPress={()=> that.navigationToScreen(this.props.data.id_order)}>
                <View style={{width:'8%'}}>
                    <Text style={stylesText.textIndex}>{index}.</Text>
                </View>
                <View style={{width:'92%'}}>
                    <Text style={stylesText.textName} numberOfLines={2}>CUSTOMERS-000{this.props.data.id_customers}</Text>
                    <Text style={stylesText.textEmail} numberOfLines={2}>Barang : {this.props.data.nama_barang}</Text>
                    <Text style={stylesText.textEmail} numberOfLines={2}>Tujuan : {this.props.data.destinasion}</Text>
                </View>
            </TouchableOpacity>
        )
    }
}

export default class ListOrderAll extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading:false,
            listOrder:[],
        };
    }

    static navigationOptions = {
        header: null
    };

    componentDidMount() {
        this.loadOrder()
        this._onFocusListener = this.props.navigation.addListener(
            "didFocus",
            payload => {
                this.loadOrder()
            }
        );
    }

    loadOrder(){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'getAllDetailOrder';
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'GET',

        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        listOrder: response.data,
                        loading:false
                    });
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    Alert(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => this.componentDidMount(), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }

    navigationToScreen(id){
        AsyncStorage.setItem('IdOrderCur', JSON.stringify(id)).then(() => {
            this.props.navigation.navigate("LocationTruckOrder");
        })
    }


    _renderOrder = ({ item, index }) => <ListOrder data={item} index={index}/>;

    render() {
        that=this;
        return (
            <Container style={stylesContent.container}>
                <Loader loading={this.state.loading} />
                <Header style={styles.header}>
                    <Left style={{ flex: 1}}>
                        <TouchableOpacity
                            transparent
                            onPress={()=> this.props.navigation.goBack()}
                            style={styles.btnBack}
                        >
                            <Image source={back} style={styles.iconMenu}/>
                        </TouchableOpacity>
                    </Left>
                    <Body style={{ flex:3, alignItems:'center'}}>
                        <Text style={styles.title}>List Semua Order</Text>
                    </Body>
                    <Right style={{ flex: 1}}>
                    </Right>
                </Header>
                <ScrollView style={{width:'100%'}}>
                    <FlatList
                        data={this.state.listOrder}
                        renderItem={this._renderOrder}
                        keyExtractor={(item, index) => index.toString()}
                    />
                    <MyView hide={this.state.listOrder=='' ? false : true }>
                        <Empty/>
                    </MyView>
                </ScrollView>
                <CustomFooter navigation={this.props.navigation} tab="ListOrderAll" />
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    title: {
        fontSize:RFValue(17),
        color:colors.white_1st,
        fontFamily: 'Roboto-Medium',
    },
    iconSearch: {
        width:'7%',
        color:colors.gray_1st,
        fontSize:RFValue(15),
    },
    btnBack: {
        width:RFValue(30),
        height:RFValue(30),
        justifyContent:'center',
        alignItems:'center'
    },
    iconMenu:{
        width:RFValue(20),
        height: RFValue(20),
    },
    iconHistory:{
        width:RFValue(30),
        height: RFValue(30),
    },
    header: {
        backgroundColor: colors.green_1st
    },
});

