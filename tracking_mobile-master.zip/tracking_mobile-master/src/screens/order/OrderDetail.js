import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    Dimensions,
    FlatList,
    ImageBackground, ScrollView
} from "react-native";
import {
    Button,
    Container, Icon, Textarea, Fab, Left, Body, Right, Header
} from "native-base";
import CustomHeader from "../../component/header/CustomHeader";
import Loader from "../../component/loader/loader";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../../component/styles/colors/index";
import MyView from "../../component/view/MyView";
var that;
import AntIcon from "react-native-vector-icons/AntDesign"
import GlobalConfig from "../../component/server/GlobalConfig";
import stylesContent from "../../component/styles/styles/stylesContent";
import stylesText from "../../component/styles/styles/stylesText";
const back = require("../../assets/icon/icon_back.png");
const troli_order = require("../../assets/icon/icon_troli_order.png");

class ListOrderDetail extends React.PureComponent {
    render() {
        let index = this.props.index + 1
        return (
            <View style={stylesContent.cardBottomWidth}>
                <View style={{width:'8%'}}>
                    <Text style={stylesText.textIndex}>{index}.</Text>
                </View>
                <View style={{width:'92%'}}>
                    <Text style={stylesText.textName} numberOfLines={2}>CUSTOMERS-000{this.props.data.id_customers}</Text>
                    <Text style={stylesText.textEmail} numberOfLines={2}>Barang : {this.props.data.nama_barang}</Text>
                    <Text style={stylesText.textEmail} numberOfLines={2}>Tujuan : {this.props.data.destinasion}</Text>
                </View>
            </View>
        )
    }
}

export default class OrderDetail extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading:false,
            listOrderDetail:[],
        };
    }

    static navigationOptions = {
        header: null
    };

    navigationScreen(route){
        this.props.navigation.navigate(route)
    }

    componentDidMount() {
        AsyncStorage.getItem("IdOrder").then(IdOrder => {
            this.setState({
                idOrder: JSON.parse(IdOrder),
            })
            this.loadOrderDetail()
        });
    }

    loadOrderDetail(){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'getDetailOrderByID';
        var formData = new FormData();
        formData.append("id_order", this.state.idOrder)
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        loading:false,
                        listOrderDetail:response.data
                    })
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    Alert(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => this.componentDidMount(), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }

    navigationToScreen(id){
        AsyncStorage.setItem('IdOrderCur', JSON.stringify(id)).then(() => {
            this.props.navigation.navigate("LocationTruckOrder");
        })
    }


    _renderOrderDetail = ({ item, index }) => <ListOrderDetail data={item} index={index}/>;

    render() {
        that=this;
        return (
            <Container style={stylesContent.container}>
                <Loader loading={this.state.loading} />
                <Header style={styles.header}>
                    <Left style={{ flex: 1}}>
                        <TouchableOpacity
                            transparent
                            onPress={()=> this.props.navigation.goBack()}
                            style={styles.btnBack}
                        >
                            <Image source={back} style={styles.iconMenu}/>
                        </TouchableOpacity>
                    </Left>
                    <Body style={{ flex:3, alignItems:'center'}}>
                        <Text style={styles.title}>Detail Order</Text>
                    </Body>
                    <Right style={{ flex: 1}}>
                        <TouchableOpacity
                            transparent
                            onPress={()=> this.navigationToScreen(this.state.idOrder)}
                            style={styles.btnBack}
                        >
                            <Image source={troli_order} style={styles.iconHistory}/>
                        </TouchableOpacity>
                    </Right>
                </Header>
                <ScrollView style={{width:'100%'}}>
                    <Text></Text>
                    <FlatList
                        data={this.state.listOrderDetail}
                        renderItem={this._renderOrderDetail}
                        keyExtractor={(item, index) => index.toString()}
                    />
                </ScrollView>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    title: {
        fontSize:RFValue(17),
        color:colors.white_1st,
        fontFamily: 'Roboto-Medium',
    },
    iconSearch: {
        width:'7%',
        color:colors.gray_1st,
        fontSize:RFValue(15),
    },
    btnBack: {
        width:RFValue(30),
        height:RFValue(30),
        justifyContent:'center',
        alignItems:'center'
    },
    iconMenu:{
        width:RFValue(20),
        height: RFValue(20),
    },
    iconHistory:{
        width:RFValue(30),
        height: RFValue(30),
    },
    header: {
        backgroundColor: colors.green_1st
    },
});

