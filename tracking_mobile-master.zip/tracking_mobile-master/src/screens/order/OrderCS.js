import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    Dimensions,
    FlatList,
    ImageBackground, ScrollView
} from "react-native";
import {
    Button,
    Container, Icon, Textarea, Fab
} from "native-base";
import CustomHeader from "../../component/header/CustomHeader";
import Loader from "../../component/loader/loader";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../../component/styles/colors/index";
import MyView from "../../component/view/MyView";
var that;
import AntIcon from "react-native-vector-icons/AntDesign"
import GlobalConfig from "../../component/server/GlobalConfig";
import stylesContent from "../../component/styles/styles/stylesContent";
import stylesText from "../../component/styles/styles/stylesText";
import IconEvil from "react-native-vector-icons/EvilIcons";
import CustomFooter from "../../component/footer/CustomFooter";
import Empty from "../../component/empty/empty";

class ListOrder extends React.PureComponent {
    render() {
        let index = this.props.index + 1
        return (
            <TouchableOpacity style={stylesContent.cardBottomWidth} onPress={()=> that.navigateToScreen(this.props.data)}>
                <View style={{width:'8%'}}>
                    <Text style={stylesText.textIndex}>{index}.</Text>
                </View>
                <View style={{width:'92%'}}>
                    <Text style={stylesText.textName} numberOfLines={2}>ORDER-000{this.props.data.id_order}</Text>
                    <Text style={stylesText.textEmail} numberOfLines={2}>Barang : {this.props.data.nama_barang}</Text>
                </View>
            </TouchableOpacity>
        )
    }
}

export default class OrderCS extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading:false,
            listOrder:[]
        };
    }

    static navigationOptions = {
        header: null
    };

    navigationScreen(route){
        this.props.navigation.navigate(route)
    }

    componentDidMount() {
        AsyncStorage.getItem("dataProfile").then(dataProfile => {
            this.setState({
                dataProfile: JSON.parse(dataProfile),
            })
            this.loadOrder()
        });

        this._onFocusListener = this.props.navigation.addListener(
            "didFocus",
            payload => {
                this.loadOrder()
            }
        );
    }

    loadOrder(){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'getDetailOrderByCustomers';
        var formData = new FormData();
        formData.append("id_customers", this.state.dataProfile.id)
        formData.append("type", 1)

        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        listOrder: response.data,
                        loading:false
                    });
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    Alert(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => this.componentDidMount(), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }

    navigateToScreen(data){
        AsyncStorage.setItem('dataOrderCS', JSON.stringify(data)).then(() => {
            this.props.navigation.navigate("OrderDetailCS");
        })
    }

    addOrder(root){
        this.props.navigation.navigate(root)
    }

    _renderOrder = ({ item, index }) => <ListOrder data={item} index={index}/>;

    render() {
        that=this;
        return (
            <Container style={stylesContent.container}>
                <Loader loading={this.state.loading} />
                <CustomHeader navigation={this.props.navigation} title='Order' left={false} right={false}/>
                <ScrollView style={{width:'100%'}}>
                    <FlatList
                        data={this.state.listOrder}
                        renderItem={this._renderOrder}
                        keyExtractor={(item, index) => index.toString()}
                    />
                    <MyView hide={this.state.listOrder=='' ? false : true }>
                        <Empty/>
                    </MyView>
                </ScrollView>
                <CustomFooter navigation={this.props.navigation} tab="OrderCS" />
            </Container>
        )
    }
}
