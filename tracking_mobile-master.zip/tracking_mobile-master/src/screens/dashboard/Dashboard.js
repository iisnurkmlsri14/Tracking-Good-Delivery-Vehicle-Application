import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    Dimensions,
    FlatList,
    BackHandler,
    ImageBackground, ScrollView
} from "react-native";
import {
    Button,
    Container, Icon
} from "native-base";
import CustomFooter from "../../component/footer/CustomFooter";
const bg_assets = require("../../assets/images/background.png");
const icon_log = require("../../assets/images/icon_log.png");
const icon_urgent = require("../../assets/icon/icon_urgent.png");
const menu_1 = require("../../assets/icon/menu_1.png");
const menu_2 = require("../../assets/icon/menu_2.png");
const menu_3 = require("../../assets/icon/menu_3.png");
import IconMI from "react-native-vector-icons/MaterialIcons";
import Loader from "../../component/loader/loader";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../../component/styles/colors/index";
import {cutRp} from "../../component/function/function";
const width = Dimensions.get('window').width
const widthImg = width * 0.94
import {convertRp, convertNoRp,  cutString} from "../../component/function/function";
import GlobalConfig from "../../component/server/GlobalConfig";
import Empty2 from "../../component/empty/empty2";
import MyView from "../../component/view/MyView";
import HandleBack from "../../component/backHandler/HandleBack";


class ListOrder extends React.PureComponent {
    render() {
        let index = this.props.index + 1
        let bg = ''
        if(index % 2 == 0){
            bg = colors.white_1st
        } else {
            bg = colors.white_2st
        }
        return (
            <View style={[styles.cardOrder,{backgroundColor:bg}]}>
                <View style={{width:'8%'}}>
                    <Text style={styles.textOrder}>{index}.</Text>
                </View>
                <View style={{width:'92%'}}>
                    <Text style={styles.textOrder}>ORDER-100{this.props.data.id_order}</Text>
                    <Text style={styles.textOrder}>{this.props.data.nama_barang}</Text>
                    <Text style={styles.textOrder}>{this.props.data.destinasion}</Text>
                </View>
            </View>
        )
    }
}

export default class Dashbord extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading:false,
            listOrder:[],
            dataJumlah:[]
        };
    }

    static navigationOptions = {
        header: null
    };

    componentDidMount() {
        this.loadTotal()
        this.loadOrder()
        this._onFocusListener = this.props.navigation.addListener(
            "didFocus",
            payload => {
                this.loadTotal()
                this.loadOrder()
            }
        );
    }

    navigationScreen(route){
        this.props.navigation.navigate(route)
    }

    loadTotal(){
        var url = GlobalConfig.URL_SERVER + 'getData';
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'GET',

        }).then((response) => response.json())
            .then((response) => {
                this.setState({
                    truck: response.truck,
                    orderON: response.orderON,
                });
            })
    }

    loadOrder(){
        var url = GlobalConfig.URL_SERVER + 'getAllDetailOrder';
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'GET',

        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        listOrder: response.data,
                    });
                }
            })
    }


    onBack = () => {
        this.setState({
            profile:false
        })
        Alert.alert(
            "Konfirmasi!",
            "Apakah Anda yakin ingin keluar dari aplikasi ?",
            [
                { text: "Tidak", onPress: () => { }, style: "cancel" },
                { text: "Ya", onPress: () => BackHandler.exitApp() },
            ],
            { cancelable: false },
        );
        return true;
    }

    _renderOrder = ({ item, index }) => <ListOrder data={item} index={index}/>;

    render() {
        return (
            <Container style={styles.container}>
                <HandleBack onBack={this.onBack}>
                <Loader loading={this.state.loading} />
                <ImageBackground source={bg_assets} style={{ width: '100%', height: '100%' }}>
                    <ScrollView style={{width:'100%'}}>
                        <View style={styles.contentHeader}>
                            <View style={styles.leftHeader}>
                                <Image source={icon_log} style={styles.iconLog}/>
                            </View>
                            <View style={styles.centerHeader}>
                                {/*<Image source={icon_text} style={styles.iconText}/>*/}
                            </View>
                            <View style={styles.rightHeader}>
                                <IconMI
                                    name='email'
                                    style={{fontSize:RFValue(20), color:colors.black_1st, marginRight:RFValue(10)}}
                                />
                                <IconMI
                                    name='notifications'
                                    style={{fontSize:RFValue(20), color:colors.black_1st}}
                                />
                            </View>
                        </View>
                        <View style={styles.contentContent}>
                            <Text style={styles.title}>Informasi</Text>
                            <View style={styles.contentSaldo}>
                                <TouchableOpacity style={[styles.saldoLeft,{backgroundColor:colors.gray_1st}]} onPress={()=> this.navigationScreen('TopUp')}>
                                    <Image source={menu_1} style={styles.iconSaldo}/>
                                    <Text style={styles.saldo}>{this.state.truck} Truck Tersedia</Text>
                                    <IconMI
                                        name='keyboard-arrow-right'
                                        style={styles.arrow}
                                    />
                                </TouchableOpacity>
                                <View style={{width:'4%'}}/>
                                <TouchableOpacity style={styles.saldoLeft} onPress={()=> this.navigationScreen('Emergency')}>
                                    <Image source={icon_urgent} style={styles.iconSaldo}/>
                                    <Text style={styles.buttonUrgent}>{this.state.orderON} Pengiriman</Text>
                                    <IconMI
                                        name='keyboard-arrow-right'
                                        style={styles.arrow}
                                    />
                                </TouchableOpacity>
                            </View>
                            <Text style={styles.title}>Menu</Text>
                            <View style={{flex:1, flexDirection:'row', marginTop: RFValue(30), marginBottom:RFValue(20)}}>
                                <TouchableOpacity style={styles.flex} onPress={()=> this.navigationScreen('Customers')}>
                                    <View style={styles.circle}>
                                        <Image source={menu_2} style={styles.iconMenu2}/>
                                    </View>
                                    <Text style={styles.titleMenu}>Kelola Customers</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.flex} onPress={()=> this.navigationScreen('Truck')}>
                                    <View style={styles.circle}>
                                        <Image source={menu_1} style={styles.iconMenu1}/>
                                    </View>
                                    <Text style={styles.titleMenu}>Kelola Truck</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.flex} onPress={()=> this.navigationScreen('Order')}>
                                    <View style={styles.circle}>
                                        <Image source={menu_3} style={styles.iconMenu3}/>
                                    </View>
                                    <Text style={styles.titleMenu} numberOfLines={2}>Kelola Order</Text>
                                </TouchableOpacity>
                            </View>
                            <View style={styles.border}/>
                            <Text style={styles.title}>List Order</Text>
                            <View style={styles.contentOrder}>
                                <FlatList
                                    data={this.state.listOrder}
                                    renderItem={this._renderOrder}
                                    keyExtractor={(item, index) => index.toString()}
                                />
                            </View>
                            <MyView hide={this.state.listOrder=='' ? true : false }>
                                <View style={styles.contentSparepart}>
                                    <TouchableOpacity style={styles.btnShop} onPress={()=> this.props.navigation.navigate('ListOrderAll')}>
                                        <Text style={styles.titleShop}>Lihat Semua</Text>
                                    </TouchableOpacity>
                                </View>
                            </MyView>
                            <MyView hide={this.state.listOrder=='' ? false : true }>
                                <Empty2/>
                            </MyView>
                        </View>
                    </ScrollView>
                    <CustomFooter navigation={this.props.navigation} tab="Dashboard" />
                </ImageBackground>
                </HandleBack>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    contentHeader:{
        flex:1,
        flexDirection:'row',
        paddingTop:RFValue(20),
        paddingHorizontal:RFValue(15)
    },
    contentContent:{
        paddingTop:RFValue(20),
        paddingHorizontal:RFValue(15)
    },
    leftHeader:{
        width:'30%',
        justifyContent:'center',
        alignItems: 'flex-start'
    },
    centerHeader:{
        width:'40%',
        justifyContent:'center',
        alignItems: 'center'
    },
    rightHeader:{
        width:'40%',
        flex:1,
        flexDirection: 'row',
        justifyContent:'flex-end',
        alignItems: 'center'
    },
    iconLog:{
        width:RFValue(100),
        height:RFValue(40),
        resizeMode:'contain'
    },
    iconText:{
        width:RFValue(100),
        height:RFValue(50),
        resizeMode:'contain'
    },
    title:{
        fontSize:RFValue(13),
        marginBottom:RFValue(5),
        fontFamily:'Roboto-Medium'
    },
    subTitle:{
        fontSize:RFValue(10),
        fontFamily:'Roboto-Light',
        marginTop:RFValue(-3)
    },
    contentProgess:{
        width:'100%',
        height:RFValue(35),
        backgroundColor:colors.gray_1st,
        borderRadius:RFValue(5),
        paddingHorizontal:RFValue(10),
        paddingVertical:RFValue(7),
        marginBottom: RFValue(20)
    },
    progressView:{
        height:'100%',
        backgroundColor: colors.green_1st,
        borderRadius: RFValue(5),
        justifyContent:'center',
        alignItems:'center'
    },
    prosent:{
        fontSize:RFValue(10),
        color:colors.white_1st
    },
    contentSaldo:{
        flex:1,
        flexDirection:'row',
        marginBottom:RFValue(20)
    },
    saldoLeft:{
        width:'48%',
        height:RFValue(30),
        borderRadius:RFValue(5),
        flex:1,
        flexDirection:'row',
        paddingHorizontal:RFValue(7),
        alignItems:'center',
    },
    iconSaldo:{
        width:RFValue(20),
        height:RFValue(20),
        resizeMode:'contain',
    },
    saldo:{
        width:'75%',
        fontSize:RFValue(12),
        color:colors.green_1st,
        textAlign:'right',
        fontFamily:'Roboto-Medium'
    },
    arrow:{
        width:'10%',
        fontSize:RFValue(20),
        color:colors.black_1st,
    },
    buttonUrgent:{
        marginLeft:RFValue(10),
        width:'75%',
        fontSize:RFValue(14),
        color:colors.black_1st,
        textAlign:'left',
        fontFamily:'Roboto-Medium'
    },
    imageCarousel: {
        height: RFValue(130),
        width: '100%',
        borderRadius: 8,
        alignSelf: 'center',
    },
    viewAll:{
        marginTop:RFValue(10),
        fontSize:RFValue(12),
        color:colors.green_1st,
        textAlign:'right',
        fontFamily:'Roboto-Medium'
    },
    border:{
        borderBottomWidth:2,
        borderColor:colors.gray_1st,
        marginHorizontal:RFValue(-15),
        marginBottom:RFValue(10)
    },
    flex:{
        width:'33%',
        justifyContent:'flex-start',
        alignItems:'center',
    },
    circle:{
        width:RFValue(60),
        height:RFValue(60),
        backgroundColor:colors.green_1st,
        borderRadius:RFValue(40),
        justifyContent:'center',
        alignItems:'center'
    },
    titleMenu:{
        marginTop:RFValue(10),
        fontSize:RFValue(12),
        color:colors.green_1st,
        textAlign:'center',
        fontFamily:'Roboto-Medium'
    },
    iconMenu1:{
        width:RFValue(85),
        height:RFValue(85),
    },
    iconMenu2:{
        width:RFValue(70),
        height:RFValue(70),
    },
    iconMenu3:{
        width:RFValue(60),
        height:RFValue(60),
    },
    contentSparepart:{
        marginTop:RFValue(10),
        marginBottom:RFValue(20),
        alignItems:'center'
    },
    contentOrder:{
        marginTop:RFValue(10),
        marginHorizontal: RFValue(-15),
    },
    btnShop:{
        marginTop:RFValue(20),
        width:'95%',
        height:RFValue(35),
        backgroundColor:colors.green_1st,
        borderRadius:RFValue(5),
        justifyContent:'center',
        alignItems:'center'
    },
    titleShop:{
        fontSize:RFValue(12),
        color:colors.white_1st,
        textAlign:'center',
        fontFamily:'Roboto-Medium'
    },
    cardOrder:{
        paddingVertical: RFValue(10),
        paddingHorizontal:RFValue(15),
        flex:1,
        flexDirection:'row'
    },
    textOrder:{
        fontSize:RFValue(12),
        color:colors.black_1st,
        fontFamily:'Roboto-Medium'
    },
    btnDetail:{
        paddingVertical:RFValue(2),
        paddingHorizontal:RFValue(7),
        backgroundColor:colors.green_1st,
        borderRadius:RFValue(5),
        justifyContent:'center',
        alignItems:'center',
        marginRight:RFValue(10)
    },
    textDetail:{
        fontSize:RFValue(10),
        color:colors.white_1st,
        fontFamily:'Roboto-Medium'
    }

});
