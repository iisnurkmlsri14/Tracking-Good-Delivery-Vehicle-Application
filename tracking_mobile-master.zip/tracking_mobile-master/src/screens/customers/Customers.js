import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    Dimensions,
    FlatList,
    ImageBackground, ScrollView
} from "react-native";
import {
    Button,
    Container, Icon, Textarea, Fab
} from "native-base";
import Dialog, {
    DialogTitle,
    SlideAnimation,
    DialogContent,
    DialogButton
} from "react-native-popup-dialog";
import CustomHeader from "../../component/header/CustomHeader";
import Loader from "../../component/loader/loader";
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../../component/styles/colors/index";
import MyView from "../../component/view/MyView";
var that;
import AntIcon from "react-native-vector-icons/AntDesign"
import GlobalConfig from "../../component/server/GlobalConfig";
import stylesContent from "../../component/styles/styles/stylesContent";
import stylesText from "../../component/styles/styles/stylesText";
import IconEvil from "react-native-vector-icons/EvilIcons";
import Empty from "../../component/empty/empty";

class ListCustomers extends React.PureComponent {
    render() {
        let index = this.props.index + 1
        return (
            <View style={stylesContent.cardBottomWidth}>
                <View style={{width:'8%'}}>
                    <Text style={stylesText.textIndex}>{index}.</Text>
                </View>
                <View style={{width:'87%'}}>
                    <Text style={stylesText.textName} numberOfLines={2}>{this.props.data.nama}, CS000{this.props.data.id}</Text>
                    <Text style={stylesText.textEmail} numberOfLines={2}>{this.props.data.email}</Text>
                </View>
                <TouchableOpacity style={{width:'5%'}} onPress={()=> that.delete(this.props.data.id)}>
                    <IconEvil name="trash" size={RFValue(20)} style={{color:colors.green_1st}}/>
                </TouchableOpacity>
            </View>
        )
    }
}

export default class Customers extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading:false,
            listCustomers:[]
        };
    }

    static navigationOptions = {
        header: null
    };

    navigationScreen(route){
        this.props.navigation.navigate(route)
    }

    componentDidMount() {
        this.loadCustomers()
        this._onFocusListener = this.props.navigation.addListener(
            "didFocus",
            payload => {
                this.loadCustomers()
            }
        );
    }

    loadCustomers(){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'getAllRegister';
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'GET',

        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        listCustomers: response.data,
                        loading:false
                    });
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    delete(id){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'deleteRegister';
        var formData = new FormData();
        formData.append("id", id)
        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        loading:false
                    })
                    setTimeout(() =>
                            this.Alert('Customers Berhasil Dihapus')
                        , 312);
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    Alert(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => this.componentDidMount(), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }
    addCustomers(root){
        this.props.navigation.navigate(root)
    }

    _renderCustomers = ({ item, index }) => <ListCustomers data={item} index={index}/>;

    render() {
        that=this;
        return (
            <Container style={stylesContent.container}>
                <Loader loading={this.state.loading} />
                <CustomHeader navigation={this.props.navigation} title='Customers' left={true} right={false}/>
                <ScrollView style={{width:'100%'}}>
                    <FlatList
                        data={this.state.listCustomers}
                        renderItem={this._renderCustomers}
                        keyExtractor={(item, index) => index.toString()}
                    />
                    <MyView hide={this.state.listCustomers=='' ? false : true }>
                        <Empty/>
                    </MyView>
                </ScrollView>
                <Fab
                    active={false}
                    direction="up"
                    containerStyle={{}}
                    style={{ backgroundColor: colors.green_1st, marginBottom: RFValue(25) }}
                    position="bottomRight"
                    onPress={() => this.addCustomers('FormCustomers')}
                >
                    <AntIcon
                        name="plus"
                        style={{
                            fontSize: RFValue(20),
                            fontWeight: "bold",
                        }}
                    />
                </Fab>
            </Container>
        )
    }
}
