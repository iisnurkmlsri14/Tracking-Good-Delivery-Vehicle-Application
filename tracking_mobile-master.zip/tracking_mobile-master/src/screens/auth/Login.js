import React, { Component } from "react";
import {
    StyleSheet,
    View,
    Image,
    Text,
    AsyncStorage,
    TouchableOpacity,
    Alert,
    TextInput,
    ScrollView,
    BackHandler
} from "react-native";
import {
    Button,
} from "native-base";
import {
    TextField,
    FilledTextField,
    OutlinedTextField,
} from 'react-native-material-textfield';
import GlobalConfig from "../../component/server/GlobalConfig";
import HandleBack from "../../component/backHandler/HandleBack";
import Loader from "../../component/loader/loader";
import PasswordInputText from 'react-native-hide-show-password-input';
import colors from "../../component/styles/colors/index";
import { RFPercentage, RFValue } from "react-native-responsive-fontsize";
import stylesContent from "../../component/styles/styles/stylesContent";
import stylesText from "../../component/styles/styles/stylesText";
const iconLogo = require('../../assets/images/icon.png');

export default class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading : false,
            email:'muhamatzaenalmahmut@gmail.com',
            password:'admin',
            // email:'farid@gmail.com',
            // password:'farid',
            // email:'',
            // password:'',
        };
    }

    static navigationOptions = {
        header: null
    };

    Alert(message){
        Alert.alert(
            'Information',
            message,
            [
                { text: 'OK', onPress: () => console.log('Cancel Pressed'), style: 'cancel' },
            ],
            { cancelable: false }
        );
    }

    konfirmasiLogin() {
        let a = "Masukkan email Anda"
        let b = "Masukkan password Anda"
        if (this.state.email == '') {
            this.Alert(a)
        } else if (this.state.password == '') {
            this.Alert(b)
        } else {
            this.generateToken()
        }
    }

    generateToken(){
        this.setState({
            loading:true
        })
        var url = GlobalConfig.URL_SERVER + 'login';
        var formData = new FormData();
        formData.append("email", this.state.email)
        formData.append("password", this.state.password)

        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                if(response.code == 200) {
                    this.setState({
                        loading:false
                    })
                    this.setProfile(response.token)
                } else {
                    this.setState({
                        loading:false
                    })
                    setTimeout(() =>
                            this.Alert('Cek Koneksi Internet Anda')
                        , 312);
                }
            })
            .catch((error) => {
                this.setState({
                    loading:false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }


    setProfile(token) {
        // this.setState({
        //     loading: true
        // })
        var url = GlobalConfig.URL_SERVER + 'validasi';
        var formData = new FormData();
        formData.append("token", token)

        fetch(url, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            method: 'POST',
            body: formData
        }).then((response) => response.json())
            .then((response) => {
                this.setState({
                    loading: false
                })
                this.navigationToScreen(response.data)
            })
            .catch((error) => {
                this.setState({
                    loading: false
                })
                setTimeout(() =>
                        this.Alert('Cek Koneksi Internet Anda')
                    , 312);
            })
    }

    navigationToScreen(dataProfile){
        AsyncStorage.setItem('dataProfile', JSON.stringify(dataProfile)).then(() => {
            if(JSON.parse(dataProfile.role_id) == 1){
                this.props.navigation.navigate("Dashboard");
            } else {
                this.props.navigation.navigate("OrderCS");
            }
        })
    }

    onBack = () => {
        BackHandler.exitApp()

        return true;
    }

    render() {
        return (
            <View style={stylesContent.container}>
                <HandleBack onBack={this.onBack}>
                <Loader loading={this.state.loading} />
                <ScrollView style={{width:'100%'}} showsVerticalScrollIndicator={false}>
                    <View style={stylesContent.content}>
                        <Image source={iconLogo} style={styles.img}/>
                        <Text style={[stylesText.title,{marginTop: RFValue(10)}]}>Tracking Sistem</Text>
                        <View style={{width:'100%', marginTop: RFValue(100)}}>
                            <TextField
                                label='Email'
                                formatText={this.formatText}
                                onSubmitEditing={this.onSubmit}
                                ref={this.fieldRef}
                                tintColor={colors.green_1st}
                                fontSize={16}
                                labelFontSize={13}
                                value={this.state.email}
                                onChangeText={(text) => this.setState({email: text})}
                            />
                            <View style={{marginTop:RFValue(5)}}/>
                            <PasswordInputText
                                tintColor={colors.green_1st}
                                fontSize={16}
                                labelFontSize={13}
                                value={this.state.password}
                                onChangeText={(text) => this.setState({password: text})}
                            />
                        </View>
                        <TouchableOpacity style={stylesContent.btnPrimary} onPress={()=>this.konfirmasiLogin()}>
                            <Text style={stylesText.btnTextPrimary}>Log In</Text>
                        </TouchableOpacity>
                    </View>
                </ScrollView>
                </HandleBack>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    img:{
        marginTop:RFValue(80),
        width:RFValue(150),
        height:RFValue(150),
        resizeMode:'contain'
    }
});

