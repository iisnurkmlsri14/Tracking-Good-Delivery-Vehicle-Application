import React from 'react';
import {
    Animated,
    StyleSheet,
    Text,
    View,
    ScrollView
} from 'react-native';
import {
    Button,
    Container,
} from 'native-base'
import {RFValue} from "react-native-responsive-fontsize";
import colors from "../../component/styles/colors/index";
const iconLogo = require('../../assets/images/icon.png')

class SplashScreen extends React.Component {
    constructor(props) {
        super(props);
        this.animatedImage = new Animated.Value(0.2);
    }

    static navigationOptions = {
        header: null
    };

    performTimeConsumingTask = async() => {
        return new Promise((resolve) =>
            setTimeout(
                () => { resolve('result') },
                1000
            )
        )
    }

    async componentDidMount() {
        Animated.spring(this.animatedImage, {
            toValue: 1,
            friction: 4,
            delay: 100,
            duration: 100,
            useNativeDriver: true,
        },).start();

        const data = await this.performTimeConsumingTask();

        if (data !== null) {
            this.props.navigation.navigate('Login');
        }
    }

    render() {
        const imageStyle = {
            transform: [{ scale: this.animatedImage }]
        };

        return (
            <Container style={styles.wrapper}>
                    <Container style={{justifyContent:'center', alignItems:'center', backgroundColor: colors.green_1st}}>
                        <Animated.View style={[styles.ring, imageStyle]}>
                            <Animated.Image
                                source={iconLogo}
                                style={[
                                    {
                                        resizeMode: "contain",
                                        width: RFValue(200),
                                        height: RFValue(200),
                                    }
                                ]}
                            />
                            <Text style={styles.welcome}>Tracking Sistem</Text>
                        </Animated.View>
                    </Container>
                    <View style={styles.contentInstansi}>
                        <Text style={styles.instansi}>POLITEKNIK ELEKTRONIKA NEGERI SURABAYA</Text>
                    </View>
            </Container>
        );
    }
}

export default SplashScreen;


const styles = StyleSheet.create({
    wrapper: {
        flex: 1,
        display: "flex",
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: colors.green_1st
    },
    ring:{
        alignItems: 'center',
        justifyContent: 'center',
    },
    welcome: {
        fontSize: RFValue(20),
        textAlign: 'center',
        fontWeight:'bold',
        color:colors.white_1st,
        fontFamily:'Roboto-Medium'
    },
    instansi:{
        fontSize: RFValue(12),
        textAlign: 'center',
        fontWeight:'bold',
        color:colors.white_1st
    },
    contentInstansi:{
        backgroundColor:colors.green_1st,
        marginBottom:RFValue(50)
    }
});
