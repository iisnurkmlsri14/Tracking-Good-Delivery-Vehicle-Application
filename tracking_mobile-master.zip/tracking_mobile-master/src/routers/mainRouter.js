import React from 'react';
import {
    createAppContainer,
    createSwitchNavigator,
    createBottomTabNavigator,
} from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import SplashScreen from '../screens/auth/SplashScreen';
import Login from "../screens/auth/Login";
import Dashboard from "../screens/dashboard/Dashboard";
import Account from "../screens/account/Account";
import Customers from "../screens/customers/Customers";
import FormCustomers from "../screens/customers/FormCustomers";
import Truck from "../screens/truck/Truck";
import FormTruck from "../screens/truck/FormTruck";
import LocationTruck from "../screens/truck/LocationTruck";
import LocationTruckOrder from "../screens/truck/LocationTruckOrder";
import LocationTruckAll from "../screens/truck/LocationTruckAll";
import Order from "../screens/order/Order";
import OrderDetail from "../screens/order/OrderDetail";
import FormOrder from "../screens/order/FormOrder";
import ListOrderAll from "../screens/order/ListOrderAll";
import ListOrderHistory from "../screens/order/ListOrderHistory";

import OrderCS from "../screens/order/OrderCS";
import OrderHistoryCS from "../screens/order/OrderHistoryCS";
import OrderDetailCS from "../screens/order/OrderDetailCS";

export const All = createStackNavigator({
    SplashScreen: {
        screen: SplashScreen
    },
    Login:{
        screen: Login
    },
    Dashboard:{
        screen: Dashboard
    },
    Account:{
        screen: Account
    },
    Customers:{
        screen: Customers
    },
    FormCustomers:{
        screen: FormCustomers
    },
    Truck:{
        screen: Truck
    },
    FormTruck:{
        screen: FormTruck
    },
    LocationTruck:{
        screen: LocationTruck
    },
    LocationTruckOrder:{
        screen: LocationTruckOrder
    },
    LocationTruckAll:{
        screen: LocationTruckAll
    },
    Order:{
        screen: Order
    },
    OrderDetail:{
        screen: OrderDetail
    },
    FormOrder:{
        screen: FormOrder
    },
    ListOrderAll:{
        screen: ListOrderAll
    },
    ListOrderHistory:{
        screen: ListOrderHistory
    },

    OrderCS:{
        screen: OrderCS
    },
    OrderHistoryCS:{
        screen: OrderHistoryCS
    },
    OrderDetailCS:{
        screen: OrderDetailCS
    }
});

export const Root = createAppContainer(All)
